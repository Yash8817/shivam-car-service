<?php
namespace PHPReportMaker12\project1;

/**
 * Page class (_user_report_rpt)
 */
class _user_report_rpt extends _user_report_base
{

	// Page ID
	public $PageID = 'rpt';

	// Project ID
	public $ProjectID = "{2B3555A9-61BF-47FE-AAE9-6AC85645A1E7}";

	// Page object name
	public $PageObjName = '_user_report_rpt';
	public $Token = "";
	public $TokenTimeout = 0;
	public $CheckToken = CHECK_TOKEN;

	// Page headings
	public $Heading = '';
	public $Subheading = '';
	public $PageHeader;
	public $PageFooter;

	// Export URLs
	public $ExportPrintUrl;
	public $ExportExcelUrl;
	public $ExportWordUrl;
	public $ExportPdfUrl;
	public $ExportEmailUrl;

	// CSS
	public $ReportTableClass = "";
	public $ReportTableStyle = "";

	// Custom export
	public $ExportPrintCustom = FALSE;
	public $ExportExcelCustom = FALSE;
	public $ExportWordCustom = FALSE;
	public $ExportPdfCustom = FALSE;
	public $ExportEmailCustom = FALSE;

	// Page heading
	public function pageHeading()
	{
		global $ReportLanguage;
		if ($this->Heading <> "")
			return $this->Heading;
		if (method_exists($this, "TableCaption"))
			return $this->tableCaption();
		return "";
	}

	// Page subheading
	public function pageSubheading()
	{
		global $ReportLanguage;
		if ($this->Subheading <> "")
			return $this->Subheading;
		return "";
	}

	// Page name
	public function pageName()
	{
		return CurrentPageName();
	}

	// Page URL
	public function pageUrl()
	{
		$pageUrl = CurrentPageName() . "?";
		if ($this->UseTokenInUrl) $pageUrl .= "t=" . $this->TableVar . "&"; // Add page token
		return $pageUrl;
	}

	// Get message
	public function getMessage()
	{
		return @$_SESSION[SESSION_MESSAGE];
	}

	// Set message
	public function setMessage($v)
	{
		AddMessage($_SESSION[SESSION_MESSAGE], $v);
	}

	// Get failure message
	public function getFailureMessage()
	{
		return @$_SESSION[SESSION_FAILURE_MESSAGE];
	}

	// Set failure message
	public function setFailureMessage($v)
	{
		AddMessage($_SESSION[SESSION_FAILURE_MESSAGE], $v);
	}

	// Get success message
	public function getSuccessMessage()
	{
		return @$_SESSION[SESSION_SUCCESS_MESSAGE];
	}

	// Set success message
	public function setSuccessMessage($v)
	{
		AddMessage($_SESSION[SESSION_SUCCESS_MESSAGE], $v);
	}

	// Get warning message
	public function getWarningMessage()
	{
		return @$_SESSION[SESSION_WARNING_MESSAGE];
	}

	// Set warning message
	public function setWarningMessage($v)
	{
		AddMessage($_SESSION[SESSION_WARNING_MESSAGE], $v);
	}

	// Clear message
	public function clearMessage()
	{
		$_SESSION[SESSION_MESSAGE] = "";
	}

	// Clear failure message
	public function clearFailureMessage()
	{
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
	}

	// Clear success message
	public function clearSuccessMessage()
	{
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
	}

	// Clear warning message
	public function clearWarningMessage()
	{
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Clear messages
	public function clearMessages()
	{
		$_SESSION[SESSION_MESSAGE] = "";
		$_SESSION[SESSION_FAILURE_MESSAGE] = "";
		$_SESSION[SESSION_SUCCESS_MESSAGE] = "";
		$_SESSION[SESSION_WARNING_MESSAGE] = "";
	}

	// Show message
	public function showMessage()
	{
		$hidden = FALSE;
		$html = "";

		// Message
		$message = $this->getMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($message, "");
		if ($message <> "") { // Message in Session, display
			if (!$hidden)
				$message = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $message;
			$html .= '<div class="alert alert-info alert-dismissible ew-info"><i class="icon fa fa-info"></i>' . $message . '</div>';
			$_SESSION[SESSION_MESSAGE] = ""; // Clear message in Session
		}

		// Warning message
		$warningMessage = $this->getWarningMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($warningMessage, "warning");
		if ($warningMessage <> "") { // Message in Session, display
			if (!$hidden)
				$warningMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $warningMessage;
			$html .= '<div class="alert alert-warning alert-dismissible ew-warning"><i class="icon fa fa-warning"></i>' . $warningMessage . '</div>';
			$_SESSION[SESSION_WARNING_MESSAGE] = ""; // Clear message in Session
		}

		// Success message
		$successMessage = $this->getSuccessMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($successMessage, "success");
		if ($successMessage <> "") { // Message in Session, display
			if (!$hidden)
				$successMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $successMessage;
			$html .= '<div class="alert alert-success alert-dismissible ew-success"><i class="icon fa fa-check"></i>' . $successMessage . '</div>';
			$_SESSION[SESSION_SUCCESS_MESSAGE] = ""; // Clear message in Session
		}

		// Failure message
		$errorMessage = $this->getFailureMessage();
		if (method_exists($this, "Message_Showing"))
			$this->Message_Showing($errorMessage, "failure");
		if ($errorMessage <> "") { // Message in Session, display
			if (!$hidden)
				$errorMessage = '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>' . $errorMessage;
			$html .= '<div class="alert alert-danger alert-dismissible ew-error"><i class="icon fa fa-ban"></i>' . $errorMessage . '</div>';
			$_SESSION[SESSION_FAILURE_MESSAGE] = ""; // Clear message in Session
		}
		echo '<div class="ew-message-dialog' . (($hidden) ? ' d-none' : "") . '">' . $html . '</div>';
	}

	// Show Page Header
	public function showPageHeader()
	{
		$header = $this->PageHeader;
		$this->Page_DataRendering($header);
		if ($header <> "") // Header exists, display
			echo '<p id="ew-page-header">' . $header . '</p>';
	}

	// Show Page Footer
	public function showPageFooter()
	{
		$footer = $this->PageFooter;
		$this->Page_DataRendered($footer);
		if ($footer <> "") // Fotoer exists, display
			echo '<p id="ew-page-footer">' . $footer . '</p>';
	}

	// Validate page request
	public function isPageRequest()
	{
		if ($this->UseTokenInUrl) {
			if (IsPost())
				return ($this->TableVar == Post("t"));
			if (Get("t") !== NULL)
				return ($this->TableVar == Get("t"));
		}
		return TRUE;
	}

	// Valid Post
	protected function validPost()
	{
		if (!$this->CheckToken || !IsPost() || IsApi())
			return TRUE;
		if (Post(TOKEN_NAME) === NULL)
			return FALSE;
		$fn = PROJECT_NAMESPACE . CHECK_TOKEN_FUNC;
		if (is_callable($fn))
			return $fn(Post(TOKEN_NAME), $this->TokenTimeout);
		return FALSE;
	}

	// Create Token
	public function createToken()
	{
		global $CurrentToken;
		$fn = PROJECT_NAMESPACE . CREATE_TOKEN_FUNC; // Always create token, required by API file/lookup request
		if ($this->Token == "" && is_callable($fn)) // Create token
			$this->Token = $fn();
		$CurrentToken = $this->Token; // Save to global variable
	}

	// Constructor
	public function __construct()
	{
		global $Language, $ReportLanguage, $DashboardReport;

		// Initialize
		if (!$DashboardReport)
			$GLOBALS["Page"] = &$this;
		$this->TokenTimeout = SessionTimeoutTime();

		// Language object
		$ReportLanguage = new ReportLanguage();
		if ($Language === NULL)
			$Language = $ReportLanguage;

		// Parent constuctor
		parent::__construct();

		// Table object (_user_report_base)
		if (!isset($GLOBALS["_user_report_base"])) {
			$GLOBALS["_user_report_base"] = &$this;
			$GLOBALS["Table"] = &$GLOBALS["_user_report_base"];
		}

		// Initialize URLs
		$this->ExportPrintUrl = $this->pageUrl() . "export=print";
		$this->ExportExcelUrl = $this->pageUrl() . "export=excel";
		$this->ExportWordUrl = $this->pageUrl() . "export=word";
		$this->ExportPdfUrl = $this->pageUrl() . "export=pdf";
		$this->ExportEmailUrl = $this->pageUrl() . "export=email";

		// Page ID
		if (!defined(PROJECT_NAMESPACE . "PAGE_ID"))
			define(PROJECT_NAMESPACE . "PAGE_ID", 'rpt');

		// Table name (for backward compatibility)
		if (!defined(PROJECT_NAMESPACE . "TABLE_NAME"))
			define(PROJECT_NAMESPACE . "TABLE_NAME", 'user report');

		// Start timer
		if (!isset($GLOBALS["DebugTimer"]))
			$GLOBALS["DebugTimer"] = new Timer();

		// Debug message
		LoadDebugMessage();

		// Open connection
		if (!isset($GLOBALS["Conn"]))
			$GLOBALS["Conn"] = &$this->getConnection();

		// Export options
		$this->ExportOptions = new ListOptions();
		$this->ExportOptions->Tag = "div";
		$this->ExportOptions->TagClassName = "ew-export-option";

		// Search options
		$this->SearchOptions = new ListOptions();
		$this->SearchOptions->Tag = "div";
		$this->SearchOptions->TagClassName = "ew-search-option";

		// Filter options
		$this->FilterOptions = new ListOptions();
		$this->FilterOptions->Tag = "div";
		$this->FilterOptions->TagClassName = "ew-filter-option f_user_reportrpt";

		// Generate report options
		$this->GenerateOptions = new ListOptions();
		$this->GenerateOptions->Tag = "div";
		$this->GenerateOptions->TagClassName = "ew-generate-option";
	}

	// Get export HTML tag
	public function getExportTag($type, $custom = FALSE)
	{
		global $ReportLanguage;
		$exportId = session_id();
		if (SameText($type, "excel")) {
			if ($custom)
				return "<a class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($ReportLanguage->phrase("ExportToExcel", TRUE)) . "\" data-caption=\"" . HtmlEncode($ReportLanguage->phrase("ExportToExcel", TRUE)) . "\" href=\"javascript:void(0);\" onclick=\"ew.exportWithCharts(event, '" . $this->ExportExcelUrl . "', '" . $exportId . "');\">" . $ReportLanguage->phrase("ExportToExcel") . "</a>";
			else
				return "<a class=\"ew-export-link ew-excel\" title=\"" . HtmlEncode($ReportLanguage->phrase("ExportToExcel", TRUE)) . "\" data-caption=\"" . HtmlEncode($ReportLanguage->phrase("ExportToExcel", TRUE)) . "\" href=\"" . $this->ExportExcelUrl . "\">" . $ReportLanguage->phrase("ExportToExcel") . "</a>";
		} elseif (SameText($type, "word")) {
			if ($custom)
				return "<a class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($ReportLanguage->phrase("ExportToWord", TRUE)) . "\" data-caption=\"" . HtmlEncode($ReportLanguage->phrase("ExportToWord", TRUE)) . "\" href=\"javascript:void(0);\" onclick=\"ew.exportWithCharts(event, '" . $this->ExportWordUrl . "', '" . $exportId . "');\">" . $ReportLanguage->phrase("ExportToWord") . "</a>";
			else
				return "<a class=\"ew-export-link ew-word\" title=\"" . HtmlEncode($ReportLanguage->phrase("ExportToWord", TRUE)) . "\" data-caption=\"" . HtmlEncode($ReportLanguage->phrase("ExportToWord", TRUE)) . "\" href=\"" . $this->ExportWordUrl . "\">" . $ReportLanguage->phrase("ExportToWord") . "</a>";
		} elseif (SameText($type, "print")) {
			if ($custom)
				return "<a class=\"ew-export-link ew-print\" title=\"" . HtmlEncode($ReportLanguage->phrase("PrinterFriendly", TRUE)) . "\" data-caption=\"" . HtmlEncode($ReportLanguage->phrase("PrinterFriendly", TRUE)) . "\" href=\"javascript:void(0);\" onclick=\"ew.exportWithCharts(event, '" . $this->ExportPrintUrl . "', '" . $exportId . "');\">" . $ReportLanguage->phrase("PrinterFriendly") . "</a>";
			else
				return "<a class=\"ew-export-link ew-print\" title=\"" . HtmlEncode($ReportLanguage->phrase("PrinterFriendly"), TRUE) . "\" data-caption=\"" . HtmlEncode($ReportLanguage->phrase("PrinterFriendly", TRUE)) . "\" href=\"" . $this->ExportPrintUrl . "\">" . $ReportLanguage->phrase("PrinterFriendly") . "</a>";
		} elseif (SameText($type, "pdf")) {
			return "<a class=\"ew-export-link ew-pdf\" title=\"" . HtmlEncode($ReportLanguage->phrase("ExportToPDF", TRUE)) . "\" data-caption=\"" . HtmlEncode($ReportLanguage->phrase("ExportToPDF", TRUE)) . "\" href=\"" . $this->ExportPdfUrl . "\">" . $ReportLanguage->phrase("ExportToPDF") . "</a>";
		} elseif (SameText($type, "email")) {
			return "<a class=\"ew-export-link ew-email\" title=\"" . HtmlEncode($ReportLanguage->phrase("ExportToEmail", TRUE)) . "\" data-caption=\"" . HtmlEncode($ReportLanguage->phrase("ExportToEmail", TRUE)) . "\" id=\"emf__user_report\" href=\"#\" onclick=\"ew.emailDialogShow({ lnk: 'emf__user_report', hdr: ew.language.phrase('ExportToEmail'), url: '$this->ExportEmailUrl', exportid: '$exportId', el: this }); return false;\">" . $ReportLanguage->phrase("ExportToEmail") . "</a>";
		}
	}

	// Set up export options
	protected function setupExportOptions()
	{
		global $Security, $ReportLanguage, $ReportOptions;
		$exportId = session_id();
		$reportTypes = [];

		// Printer friendly
		$item = &$this->ExportOptions->add("print");
		$item->Body = $this->getExportTag("print");
		$item->Visible = FALSE;
		$reportTypes["print"] = $item->Visible ? $ReportLanguage->phrase("ReportFormPrint") : "";

		// Export to Excel
		$item = &$this->ExportOptions->add("excel");
		$item->Body = $this->getExportTag("excel");
		$item->Visible = FALSE;
		$reportTypes["excel"] = $item->Visible ? $ReportLanguage->phrase("ReportFormExcel") : "";

		// Export to Word
		$item = &$this->ExportOptions->add("word");
		$item->Body = $this->getExportTag("word");
		$item->Visible = FALSE;
		$reportTypes["word"] = $item->Visible ? $ReportLanguage->phrase("ReportFormWord") : "";

		// Export to Pdf
		$item = &$this->ExportOptions->add("pdf");
		$item->Body = $this->getExportTag("pdf");
		$item->Visible = FALSE;
		$item->Visible = TRUE;
		$reportTypes["pdf"] = $item->Visible ? $ReportLanguage->phrase("ReportFormPdf") : "";

		// Export to Email
		$item = &$this->ExportOptions->add("email");
		$item->Body = $this->getExportTag("email");
		$item->Visible = FALSE;
		$reportTypes["email"] = $item->Visible ? $ReportLanguage->phrase("ReportFormEmail") : "";

		// Report types
		$ReportOptions["ReportTypes"] = $reportTypes;

		// Drop down button for export
		$this->ExportOptions->UseDropDownButton = FALSE;
		$this->ExportOptions->UseButtonGroup = TRUE;
		$this->ExportOptions->UseImageAndText = $this->ExportOptions->UseDropDownButton;
		$this->ExportOptions->DropDownButtonPhrase = $ReportLanguage->phrase("ButtonExport");

		// Add group option item
		$item = &$this->ExportOptions->add($this->ExportOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Filter button
		$item = &$this->FilterOptions->add("savecurrentfilter");
		$item->Body = "<a class=\"ew-save-filter\" data-form=\"f_user_reportrpt\" href=\"#\">" . $ReportLanguage->phrase("SaveCurrentFilter") . "</a>";
		$item->Visible = TRUE;
		$item = &$this->FilterOptions->add("deletefilter");
		$item->Body = "<a class=\"ew-delete-filter\" data-form=\"f_user_reportrpt\" href=\"#\">" . $ReportLanguage->phrase("DeleteFilter") . "</a>";
		$item->Visible = TRUE;
		$this->FilterOptions->UseDropDownButton = TRUE;
		$this->FilterOptions->UseButtonGroup = !$this->FilterOptions->UseDropDownButton; // v8
		$this->FilterOptions->DropDownButtonPhrase = $ReportLanguage->phrase("Filters");

		// Add group option item
		$item = &$this->FilterOptions->add($this->FilterOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Set up export options (extended)
		$this->setupExportOptionsExt();

		// Hide options for export
		if ($this->isExport()) {
			$this->ExportOptions->hideAllOptions();
			$this->FilterOptions->hideAllOptions();
		}

		// Set up table class
		if ($this->isExport("word") || $this->isExport("excel") || $this->isExport("pdf"))
			$this->ReportTableClass = "ew-table";
		else
			$this->ReportTableClass = "table ew-table";
	}

	// Set up search options
	protected function setupSearchOptions()
	{
		global $ReportLanguage;

		// Filter panel button
		$item = &$this->SearchOptions->add("searchtoggle");
		$searchToggleClass = $this->FilterApplied ? " active" : " active";
		$item->Body = "<button type=\"button\" class=\"btn btn-default ew-search-toggle" . $searchToggleClass . "\" title=\"" . $ReportLanguage->phrase("SearchBtn", TRUE) . "\" data-caption=\"" . $ReportLanguage->phrase("SearchBtn", TRUE) . "\" data-toggle=\"button\" data-form=\"f_user_reportrpt\">" . $ReportLanguage->phrase("SearchBtn") . "</button>";
		$item->Visible = TRUE;

		// Reset filter
		$item = &$this->SearchOptions->add("resetfilter");
		$item->Body = "<button type=\"button\" class=\"btn btn-default\" title=\"" . HtmlEncode($ReportLanguage->phrase("ResetAllFilter", TRUE)) . "\" data-caption=\"" . HtmlEncode($ReportLanguage->phrase("ResetAllFilter", TRUE)) . "\" onclick=\"location='" . CurrentPageName() . "?cmd=reset'\">" . $ReportLanguage->phrase("ResetAllFilter") . "</button>";
		$item->Visible = TRUE && $this->FilterApplied;

		// Button group for reset filter
		$this->SearchOptions->UseButtonGroup = TRUE;

		// Add group option item
		$item = &$this->SearchOptions->add($this->SearchOptions->GroupOptionName);
		$item->Body = "";
		$item->Visible = FALSE;

		// Hide options for export
		if ($this->isExport())
			$this->SearchOptions->hideAllOptions();
	}

	// Terminate page
	public function terminate($url = "")
	{
		global $ReportLanguage, $EXPORT_REPORT, $ExportFileName, $DashboardReport;

		// Page Unload event
		$this->Page_Unload();

		// Global Page Unloaded event (in userfn*.php)
		Page_Unloaded();

		// Export
		if ($this->isExport() && array_key_exists($this->Export, $EXPORT_REPORT)) {
			$content = ob_get_contents();
			if (ob_get_length())
				ob_end_clean();

			// Remove all <div data-tagid="..." id="orig..." class="hide">...</div> (for customviewtag export, except "googlemaps")
			if (preg_match_all('/<div\s+data-tagid=[\'"]([\s\S]*?)[\'"]\s+id=[\'"]orig([\s\S]*?)[\'"]\s+class\s*=\s*[\'"]hide[\'"]>([\s\S]*?)<\/div\s*>/i', $content, $divmatches, PREG_SET_ORDER)) {
				foreach ($divmatches as $divmatch) {
					if ($divmatch[1] <> "googlemaps")
						$content = str_replace($divmatch[0], "", $content);
				}
			}
			$fn = $EXPORT_REPORT[$this->Export];
			$saveResponse = $this->$fn($content);
			if (ReportParam("generaterequest") === TRUE) { // Generate report request
				$this->writeGenResponse($saveResponse);
				$url = ""; // Avoid redirect
			}
		}

		// Close connection if not in dashboard
		if (!$DashboardReport)
			CloseConnections();

		// Go to URL if specified
		if ($url <> "") {
			if (!DEBUG_ENABLED && ob_get_length())
				ob_end_clean();
			SaveDebugMessage();
			header("Location: " . $url);
		}
		if (!$DashboardReport)
			exit();
	}

	// Initialize common variables
	public $ExportOptions; // Export options
	public $SearchOptions; // Search options
	public $FilterOptions; // Filter options

	// Recordset
	public $GroupRecordset = NULL;
	public $Recordset = NULL;
	public $DetailRecordCount = 0;

	// Paging variables
	public $RecordIndex = 0; // Record index
	public $RecordCount = 0; // Record count
	public $StartGroup = 0; // Start group
	public $StopGroup = 0; // Stop group
	public $TotalGroups = 0; // Total groups
	public $GroupCount = 0; // Group count
	public $GroupCounter = []; // Group counter
	public $DisplayGroups = 3; // Groups per page
	public $GroupRange = 10;
	public $Sort = "";
	public $Filter = "";
	public $PageFirstGroupFilter = "";
	public $UserIDFilter = "";
	public $DrillDown = FALSE;
	public $DrillDownInPanel = FALSE;
	public $DrillDownList = "";

	// Clear field for ext filter
	public $ExpiredExtendedFilter = "";
	public $PopupName = "";
	public $PopupValue = "";
	public $FilterApplied;
	public $SearchCommand = FALSE;
	public $ShowHeader;
	public $GroupColumnCount = 0;
	public $SubGroupColumnCount = 0;
	public $DetailColumnCount = 0;
	public $Counts;
	public $Columns;
	public $Values;
	public $Summaries;
	public $Minimums;
	public $Maximums;
	public $GrandCounts;
	public $GrandSummaries;
	public $GrandMinimums;
	public $GrandMaximums;
	public $TotalCount;
	public $GrandSummarySetup = FALSE;
	public $GroupIndexes;
	public $DetailRows = [];
	public $TopContentClass = "col-sm-12 ew-top";
	public $LeftContentClass = "ew-left";
	public $CenterContentClass = "col-sm-12 ew-center";
	public $RightContentClass = "ew-right";
	public $BottomContentClass = "col-sm-12 ew-bottom";

	//
	// Page run
	//

	public function run()
	{
		global $ExportType, $ExportFileName, $ReportLanguage, $Security, $UserProfile,
			$Security, $FormError, $DrillDownInPanel, $Breadcrumb, $ReportLanguage,
			$DashboardReport, $CustomExportType;
		global $ReportLanguage;

		// Get export parameters
		if (ReportParam("export") !== NULL)
			$this->Export = strtolower(ReportParam("export"));
		$ExportType = $this->Export; // Get export parameter, used in header
		$ExportFileName = $this->TableVar; // Get export file, used in header

		// Setup placeholder
		$this->app_date->PlaceHolder = $this->app_date->caption();

		// Setup export options
		$this->setupExportOptions();

		// Global Page Loading event (in userfn*.php)
		Page_Loading();

		// Page Load event
		$this->Page_Load();

		// Check token
		if (!$this->validPost()) {
			echo $ReportLanguage->phrase("InvalidPostRequest");
			$this->terminate();
			exit();
		}

		// Create Token
		$this->createToken();

		// Set up lookup cache
		// Set field visibility for detail fields

		$this->appointment_id->setVisibility();
		$this->app_date->setVisibility();
		$this->app_time->setVisibility();
		$this->Vehicle_rto_number->setVisibility();
		$this->staffstaff_id->setVisibility();
		$this->customercustomer_id->setVisibility();
		$this->statusstatus_id->setVisibility();
		$this->customer_id->setVisibility();
		$this->Useruser_id->setVisibility();
		$this->reg_date->setVisibility();
		$this->user_id->setVisibility();
		$this->user_name->setVisibility();
		$this->user_pass->setVisibility();
		$this->user_email->setVisibility();
		$this->user_add->setVisibility();
		$this->user_phone->setVisibility();
		$this->user_sec_ques->setVisibility();
		$this->user_sec_ans->setVisibility();
		$this->companycompany_id->setVisibility();
		$this->otp->setVisibility();

		// Aggregate variables
		// 1st dimension = no of groups (level 0 used for grand total)
		// 2nd dimension = no of fields

		$fieldCount = 21;
		$groupCount = 1;
		$this->Values = &InitArray($fieldCount, 0);
		$this->Counts = &Init2DArray($groupCount, $fieldCount, 0);
		$this->Summaries = &Init2DArray($groupCount, $fieldCount, 0);
		$this->Minimums = &Init2DArray($groupCount, $fieldCount, NULL);
		$this->Maximums = &Init2DArray($groupCount, $fieldCount, NULL);
		$this->GrandCounts = &InitArray($fieldCount, 0);
		$this->GrandSummaries = &InitArray($fieldCount, 0);
		$this->GrandMinimums = &InitArray($fieldCount, NULL);
		$this->GrandMaximums = &InitArray($fieldCount, NULL);

		// Set up array if accumulation required: [Accum, SkipNullOrZero]
		$this->Columns = [[FALSE, FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE], [FALSE,FALSE]];

		// Set up groups per page dynamically
		$this->setupDisplayGroups();

		// Set up Breadcrumb
		if (!$this->isExport())
			$this->setupBreadcrumb();
		$this->app_date->SelectionList = "";
		$this->app_date->DefaultSelectionList = "";
		$this->app_date->ValueList = "";

		// Check if search command
		$this->SearchCommand = (Get("cmd", "") == "search");

		// Load default filter values
		$this->loadDefaultFilters();

		// Load custom filters
		$this->Page_FilterLoad();

		// Set up popup filter
		$this->setupPopup();

		// Load group db values if necessary
		$this->loadGroupDbValues();

		// Extended filter
		$extendedFilter = "";

		// Restore filter list
		$this->restoreFilterList();

		// Build extended filter
		$extendedFilter = $this->getExtendedFilter();
		AddFilter($this->Filter, $extendedFilter);

		// Build popup filter
		$popupFilter = $this->getPopupFilter();
		AddFilter($this->Filter, $popupFilter);

		// Check if filter applied
		$this->FilterApplied = $this->checkFilter();

		// Call Page Selecting event
		$this->Page_Selecting($this->Filter);

		// Search options
		$this->setupSearchOptions();

		// Get sort
		$this->Sort = $this->getSort();

		// Get total count
		$sql = BuildReportSql($this->getSqlSelect(), $this->getSqlWhere(), $this->getSqlGroupBy(), $this->getSqlHaving(), "", $this->Filter, "");
		$this->TotalGroups = $this->getRecordCount($sql);
		if ($this->DisplayGroups <= 0 || $this->DrillDown || $DashboardReport) // Display all groups
			$this->DisplayGroups = $this->TotalGroups;
		$this->StartGroup = 1;

		// Show header
		$this->ShowHeader = TRUE;

		// Set up start position if not export all
		if ($this->ExportAll && $this->isExport())
			$this->DisplayGroups = $this->TotalGroups;
		else
			$this->setupStartGroup();

		// Set no record found message
		if ($this->TotalGroups == 0) {
				if ($this->Filter == "0=101") {
					$this->setWarningMessage($ReportLanguage->phrase("EnterSearchCriteria"));
				} else {
					$this->setWarningMessage($ReportLanguage->phrase("NoRecord"));
				}
		}

		// Hide export options if export/dashboard report
		if ($this->isExport() || $DashboardReport)
			$this->ExportOptions->hideAllOptions();

		// Hide search/filter options if export/drilldown/dashboard report
		if ($this->isExport() || $this->DrillDown || $DashboardReport) {
			$this->SearchOptions->hideAllOptions();
			$this->FilterOptions->hideAllOptions();
			$this->GenerateOptions->hideAllOptions();
		}

		// Get current page records
		$sql = BuildReportSql($this->getSqlSelect(), $this->getSqlWhere(), $this->getSqlGroupBy(), $this->getSqlHaving(), $this->getSqlOrderBy(), $this->Filter, $this->Sort);
		$this->Recordset = $this->getRecordset($sql, $this->DisplayGroups, $this->StartGroup - 1);
		$this->setupFieldCount();
	}

	// Accummulate summary
	public function accumulateSummary()
	{
		$cntx = count($this->Summaries);
		for ($ix = 0; $ix < $cntx; $ix++) {
			$cnty = count($this->Summaries[$ix]);
			for ($iy = 1; $iy < $cnty; $iy++) {
				if ($this->Columns[$iy][0]) { // Accumulate required
					$valwrk = $this->Values[$iy];
					if ($valwrk === NULL) {
						if (!$this->Columns[$iy][1])
							$this->Counts[$ix][$iy]++;
					} else {
						$accum = (!$this->Columns[$iy][1] || !is_numeric($valwrk) || $valwrk <> 0);
						if ($accum) {
							$this->Counts[$ix][$iy]++;
							if (is_numeric($valwrk)) {
								$this->Summaries[$ix][$iy] += $valwrk;
								if ($this->Minimums[$ix][$iy] === NULL) {
									$this->Minimums[$ix][$iy] = $valwrk;
									$this->Maximums[$ix][$iy] = $valwrk;
								} else {
									if ($this->Minimums[$ix][$iy] > $valwrk)
										$this->Minimums[$ix][$iy] = $valwrk;
									if ($this->Maximums[$ix][$iy] < $valwrk)
										$this->Maximums[$ix][$iy] = $valwrk;
								}
							}
						}
					}
				}
			}
		}
		$cntx = count($this->Summaries);
		for ($ix = 0; $ix < $cntx; $ix++)
			$this->Counts[$ix][0]++;
	}

	// Reset level summary
	public function resetLevelSummary($lvl)
	{

		// Clear summary values
		$cntx = count($this->Summaries);
		for ($ix = $lvl; $ix < $cntx; $ix++) {
			$cnty = count($this->Summaries[$ix]);
			for ($iy = 1; $iy < $cnty; $iy++) {
				$this->Counts[$ix][$iy] = 0;
				if ($this->Columns[$iy][0]) {
					$this->Summaries[$ix][$iy] = 0;
					$this->Minimums[$ix][$iy] = NULL;
					$this->Maximums[$ix][$iy] = NULL;
				}
			}
		}
		$cntx = count($this->Summaries);
		for ($ix = $lvl; $ix < $cntx; $ix++)
			$this->Counts[$ix][0] = 0;

		// Reset record count
		$this->RecordCount = 0;
	}

	// Load row values
	public function loadRowValues($firstRow = FALSE)
	{
		if (!$this->Recordset)
			return;
		if ($firstRow) { // Get first row
				$this->FirstRowData = [];
				$this->FirstRowData["appointment_id"] = $this->Recordset->fields('appointment_id');
				$this->FirstRowData["app_date"] = $this->Recordset->fields('app_date');
				$this->FirstRowData["app_time"] = $this->Recordset->fields('app_time');
				$this->FirstRowData["Vehicle_rto_number"] = $this->Recordset->fields('Vehicle_rto_number');
				$this->FirstRowData["staffstaff_id"] = $this->Recordset->fields('staffstaff_id');
				$this->FirstRowData["customercustomer_id"] = $this->Recordset->fields('customercustomer_id');
				$this->FirstRowData["statusstatus_id"] = $this->Recordset->fields('statusstatus_id');
				$this->FirstRowData["customer_id"] = $this->Recordset->fields('customer_id');
				$this->FirstRowData["Useruser_id"] = $this->Recordset->fields('Useruser_id');
				$this->FirstRowData["reg_date"] = $this->Recordset->fields('reg_date');
				$this->FirstRowData["user_id"] = $this->Recordset->fields('user_id');
				$this->FirstRowData["user_name"] = $this->Recordset->fields('user_name');
				$this->FirstRowData["user_pass"] = $this->Recordset->fields('user_pass');
				$this->FirstRowData["user_email"] = $this->Recordset->fields('user_email');
				$this->FirstRowData["user_add"] = $this->Recordset->fields('user_add');
				$this->FirstRowData["user_phone"] = $this->Recordset->fields('user_phone');
				$this->FirstRowData["user_sec_ques"] = $this->Recordset->fields('user_sec_ques');
				$this->FirstRowData["user_sec_ans"] = $this->Recordset->fields('user_sec_ans');
				$this->FirstRowData["companycompany_id"] = $this->Recordset->fields('companycompany_id');
				$this->FirstRowData["otp"] = $this->Recordset->fields('otp');
		} else { // Get next row
			$this->Recordset->moveNext();
		}
		if (!$this->Recordset->EOF) {
			$this->appointment_id->setDbValue($this->Recordset->fields('appointment_id'));
			$this->app_date->setDbValue($this->Recordset->fields('app_date'));
			$this->app_time->setDbValue($this->Recordset->fields('app_time'));
			$this->Vehicle_rto_number->setDbValue($this->Recordset->fields('Vehicle_rto_number'));
			$this->staffstaff_id->setDbValue($this->Recordset->fields('staffstaff_id'));
			$this->customercustomer_id->setDbValue($this->Recordset->fields('customercustomer_id'));
			$this->statusstatus_id->setDbValue($this->Recordset->fields('statusstatus_id'));
			$this->customer_id->setDbValue($this->Recordset->fields('customer_id'));
			$this->Useruser_id->setDbValue($this->Recordset->fields('Useruser_id'));
			$this->reg_date->setDbValue($this->Recordset->fields('reg_date'));
			$this->user_id->setDbValue($this->Recordset->fields('user_id'));
			$this->user_name->setDbValue($this->Recordset->fields('user_name'));
			$this->user_pass->setDbValue($this->Recordset->fields('user_pass'));
			$this->user_email->setDbValue($this->Recordset->fields('user_email'));
			$this->user_add->setDbValue($this->Recordset->fields('user_add'));
			$this->user_phone->setDbValue($this->Recordset->fields('user_phone'));
			$this->user_sec_ques->setDbValue($this->Recordset->fields('user_sec_ques'));
			$this->user_sec_ans->setDbValue($this->Recordset->fields('user_sec_ans'));
			$this->companycompany_id->setDbValue($this->Recordset->fields('companycompany_id'));
			$this->otp->setDbValue($this->Recordset->fields('otp'));
			$this->Values[1] = $this->appointment_id->CurrentValue;
			$this->Values[2] = $this->app_date->CurrentValue;
			$this->Values[3] = $this->app_time->CurrentValue;
			$this->Values[4] = $this->Vehicle_rto_number->CurrentValue;
			$this->Values[5] = $this->staffstaff_id->CurrentValue;
			$this->Values[6] = $this->customercustomer_id->CurrentValue;
			$this->Values[7] = $this->statusstatus_id->CurrentValue;
			$this->Values[8] = $this->customer_id->CurrentValue;
			$this->Values[9] = $this->Useruser_id->CurrentValue;
			$this->Values[10] = $this->reg_date->CurrentValue;
			$this->Values[11] = $this->user_id->CurrentValue;
			$this->Values[12] = $this->user_name->CurrentValue;
			$this->Values[13] = $this->user_pass->CurrentValue;
			$this->Values[14] = $this->user_email->CurrentValue;
			$this->Values[15] = $this->user_add->CurrentValue;
			$this->Values[16] = $this->user_phone->CurrentValue;
			$this->Values[17] = $this->user_sec_ques->CurrentValue;
			$this->Values[18] = $this->user_sec_ans->CurrentValue;
			$this->Values[19] = $this->companycompany_id->CurrentValue;
			$this->Values[20] = $this->otp->CurrentValue;
		} else {
			$this->appointment_id->setDbValue("");
			$this->app_date->setDbValue("");
			$this->app_time->setDbValue("");
			$this->Vehicle_rto_number->setDbValue("");
			$this->staffstaff_id->setDbValue("");
			$this->customercustomer_id->setDbValue("");
			$this->statusstatus_id->setDbValue("");
			$this->customer_id->setDbValue("");
			$this->Useruser_id->setDbValue("");
			$this->reg_date->setDbValue("");
			$this->user_id->setDbValue("");
			$this->user_name->setDbValue("");
			$this->user_pass->setDbValue("");
			$this->user_email->setDbValue("");
			$this->user_add->setDbValue("");
			$this->user_phone->setDbValue("");
			$this->user_sec_ques->setDbValue("");
			$this->user_sec_ans->setDbValue("");
			$this->companycompany_id->setDbValue("");
			$this->otp->setDbValue("");
		}
	}

	// Render row
	public function renderRow()
	{
		global $Security, $ReportLanguage, $Language;
		$conn = &$this->getConnection();
		if (!$this->GrandSummarySetup) { // Get Grand total
			$hasCount = FALSE;
			$hasSummary = FALSE;

			// Get total count from SQL directly
			$sql = BuildReportSql($this->getSqlSelectCount(), $this->getSqlWhere(), $this->getSqlGroupBy(), $this->getSqlHaving(), "", $this->Filter, "");
			$rstot = $conn->execute($sql);
			if ($rstot) {
				$this->TotalCount = ($rstot->recordCount() > 1) ? $rstot->recordCount() : $rstot->fields[0];
				$rstot->close();
				$hasCount = TRUE;
			} else {
				$this->TotalCount = 0;
			}
			$hasSummary = TRUE;

			// Accumulate grand summary from detail records
			if (!$hasCount || !$hasSummary) {
				$sql = BuildReportSql($this->getSqlSelect(), $this->getSqlWhere(), $this->getSqlGroupBy(), $this->getSqlHaving(), "", $this->Filter, "");
				$this->Recordset = $conn->execute($sql);
				if ($this->Recordset) {
					$this->loadRowValues(TRUE);
					while (!$this->Recordset->EOF) {
						$this->accumulateGrandSummary();
						$this->loadRowValues();
					}
					$this->Recordset->close();
				}
			}
			$this->GrandSummarySetup = TRUE; // No need to set up again
		}

		// Call Row_Rendering event
		$this->Row_Rendering();
		if ($this->RowType == ROWTYPE_SEARCH) { // Search row
		} elseif ($this->RowType == ROWTYPE_TOTAL && !($this->RowTotalType == ROWTOTAL_GROUP && $this->RowTotalSubType == ROWTOTAL_HEADER)) { // Summary row
			PrependClass($this->RowAttrs["class"], ($this->RowTotalType == ROWTOTAL_PAGE || $this->RowTotalType == ROWTOTAL_GRAND) ? "ew-rpt-grp-aggregate" : ""); // Set up row class

			// appointment_id
			$this->appointment_id->HrefValue = "";

			// app_date
			$this->app_date->HrefValue = "";

			// app_time
			$this->app_time->HrefValue = "";

			// Vehicle_rto_number
			$this->Vehicle_rto_number->HrefValue = "";

			// staffstaff_id
			$this->staffstaff_id->HrefValue = "";

			// customercustomer_id
			$this->customercustomer_id->HrefValue = "";

			// statusstatus_id
			$this->statusstatus_id->HrefValue = "";

			// customer_id
			$this->customer_id->HrefValue = "";

			// Useruser_id
			$this->Useruser_id->HrefValue = "";

			// reg_date
			$this->reg_date->HrefValue = "";

			// user_id
			$this->user_id->HrefValue = "";

			// user_name
			$this->user_name->HrefValue = "";

			// user_pass
			$this->user_pass->HrefValue = "";

			// user_email
			$this->user_email->HrefValue = "";

			// user_add
			$this->user_add->HrefValue = "";

			// user_phone
			$this->user_phone->HrefValue = "";

			// user_sec_ques
			$this->user_sec_ques->HrefValue = "";

			// user_sec_ans
			$this->user_sec_ans->HrefValue = "";

			// companycompany_id
			$this->companycompany_id->HrefValue = "";

			// otp
			$this->otp->HrefValue = "";
		} else {
			if ($this->RowTotalType == ROWTOTAL_GROUP && $this->RowTotalSubType == ROWTOTAL_HEADER) {
			} else {
			}

			// appointment_id
			$this->appointment_id->ViewValue = $this->appointment_id->CurrentValue;
			$this->appointment_id->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// app_date
			$this->app_date->ViewValue = $this->app_date->CurrentValue;
			$this->app_date->ViewValue = FormatDateTime($this->app_date->ViewValue, 0);
			$this->app_date->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// app_time
			$this->app_time->ViewValue = $this->app_time->CurrentValue;
			$this->app_time->ViewValue = FormatDateTime($this->app_time->ViewValue, 4);
			$this->app_time->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// Vehicle_rto_number
			$this->Vehicle_rto_number->ViewValue = $this->Vehicle_rto_number->CurrentValue;
			$this->Vehicle_rto_number->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// staffstaff_id
			$this->staffstaff_id->ViewValue = $this->staffstaff_id->CurrentValue;
			$this->staffstaff_id->ViewValue = FormatNumber($this->staffstaff_id->ViewValue, 0, -2, -2, -2);
			$this->staffstaff_id->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// customercustomer_id
			$this->customercustomer_id->ViewValue = $this->customercustomer_id->CurrentValue;
			$this->customercustomer_id->ViewValue = FormatNumber($this->customercustomer_id->ViewValue, 0, -2, -2, -2);
			$this->customercustomer_id->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// statusstatus_id
			$this->statusstatus_id->ViewValue = $this->statusstatus_id->CurrentValue;
			$this->statusstatus_id->ViewValue = FormatNumber($this->statusstatus_id->ViewValue, 0, -2, -2, -2);
			$this->statusstatus_id->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// customer_id
			$this->customer_id->ViewValue = $this->customer_id->CurrentValue;
			$this->customer_id->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// Useruser_id
			$this->Useruser_id->ViewValue = $this->Useruser_id->CurrentValue;
			$this->Useruser_id->ViewValue = FormatNumber($this->Useruser_id->ViewValue, 0, -2, -2, -2);
			$this->Useruser_id->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// reg_date
			$this->reg_date->ViewValue = $this->reg_date->CurrentValue;
			$this->reg_date->ViewValue = FormatDateTime($this->reg_date->ViewValue, 0);
			$this->reg_date->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// user_id
			$this->user_id->ViewValue = $this->user_id->CurrentValue;
			$this->user_id->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// user_name
			$this->user_name->ViewValue = $this->user_name->CurrentValue;
			$this->user_name->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// user_pass
			$this->user_pass->ViewValue = $this->user_pass->CurrentValue;
			$this->user_pass->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// user_email
			$this->user_email->ViewValue = $this->user_email->CurrentValue;
			$this->user_email->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// user_add
			$this->user_add->ViewValue = $this->user_add->CurrentValue;
			$this->user_add->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// user_phone
			$this->user_phone->ViewValue = $this->user_phone->CurrentValue;
			$this->user_phone->ViewValue = FormatNumber($this->user_phone->ViewValue, 0, -2, -2, -2);
			$this->user_phone->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// user_sec_ques
			$this->user_sec_ques->ViewValue = $this->user_sec_ques->CurrentValue;
			$this->user_sec_ques->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// user_sec_ans
			$this->user_sec_ans->ViewValue = $this->user_sec_ans->CurrentValue;
			$this->user_sec_ans->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// companycompany_id
			$this->companycompany_id->ViewValue = $this->companycompany_id->CurrentValue;
			$this->companycompany_id->ViewValue = FormatNumber($this->companycompany_id->ViewValue, 0, -2, -2, -2);
			$this->companycompany_id->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// otp
			$this->otp->ViewValue = $this->otp->CurrentValue;
			$this->otp->ViewValue = FormatNumber($this->otp->ViewValue, 0, -2, -2, -2);
			$this->otp->CellAttrs["class"] = ($this->RecordCount % 2 <> 1 ? "ew-table-alt-row" : "ew-table-row");

			// appointment_id
			$this->appointment_id->HrefValue = "";

			// app_date
			$this->app_date->HrefValue = "";

			// app_time
			$this->app_time->HrefValue = "";

			// Vehicle_rto_number
			$this->Vehicle_rto_number->HrefValue = "";

			// staffstaff_id
			$this->staffstaff_id->HrefValue = "";

			// customercustomer_id
			$this->customercustomer_id->HrefValue = "";

			// statusstatus_id
			$this->statusstatus_id->HrefValue = "";

			// customer_id
			$this->customer_id->HrefValue = "";

			// Useruser_id
			$this->Useruser_id->HrefValue = "";

			// reg_date
			$this->reg_date->HrefValue = "";

			// user_id
			$this->user_id->HrefValue = "";

			// user_name
			$this->user_name->HrefValue = "";

			// user_pass
			$this->user_pass->HrefValue = "";

			// user_email
			$this->user_email->HrefValue = "";

			// user_add
			$this->user_add->HrefValue = "";

			// user_phone
			$this->user_phone->HrefValue = "";

			// user_sec_ques
			$this->user_sec_ques->HrefValue = "";

			// user_sec_ans
			$this->user_sec_ans->HrefValue = "";

			// companycompany_id
			$this->companycompany_id->HrefValue = "";

			// otp
			$this->otp->HrefValue = "";
		}

		// Call Cell_Rendered event
		if ($this->RowType == ROWTYPE_TOTAL) { // Summary row
		} else {

			// appointment_id
			$currentValue = $this->appointment_id->CurrentValue;
			$viewValue = &$this->appointment_id->ViewValue;
			$viewAttrs = &$this->appointment_id->ViewAttrs;
			$cellAttrs = &$this->appointment_id->CellAttrs;
			$hrefValue = &$this->appointment_id->HrefValue;
			$linkAttrs = &$this->appointment_id->LinkAttrs;
			$this->Cell_Rendered($this->appointment_id, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// app_date
			$currentValue = $this->app_date->CurrentValue;
			$viewValue = &$this->app_date->ViewValue;
			$viewAttrs = &$this->app_date->ViewAttrs;
			$cellAttrs = &$this->app_date->CellAttrs;
			$hrefValue = &$this->app_date->HrefValue;
			$linkAttrs = &$this->app_date->LinkAttrs;
			$this->Cell_Rendered($this->app_date, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// app_time
			$currentValue = $this->app_time->CurrentValue;
			$viewValue = &$this->app_time->ViewValue;
			$viewAttrs = &$this->app_time->ViewAttrs;
			$cellAttrs = &$this->app_time->CellAttrs;
			$hrefValue = &$this->app_time->HrefValue;
			$linkAttrs = &$this->app_time->LinkAttrs;
			$this->Cell_Rendered($this->app_time, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// Vehicle_rto_number
			$currentValue = $this->Vehicle_rto_number->CurrentValue;
			$viewValue = &$this->Vehicle_rto_number->ViewValue;
			$viewAttrs = &$this->Vehicle_rto_number->ViewAttrs;
			$cellAttrs = &$this->Vehicle_rto_number->CellAttrs;
			$hrefValue = &$this->Vehicle_rto_number->HrefValue;
			$linkAttrs = &$this->Vehicle_rto_number->LinkAttrs;
			$this->Cell_Rendered($this->Vehicle_rto_number, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// staffstaff_id
			$currentValue = $this->staffstaff_id->CurrentValue;
			$viewValue = &$this->staffstaff_id->ViewValue;
			$viewAttrs = &$this->staffstaff_id->ViewAttrs;
			$cellAttrs = &$this->staffstaff_id->CellAttrs;
			$hrefValue = &$this->staffstaff_id->HrefValue;
			$linkAttrs = &$this->staffstaff_id->LinkAttrs;
			$this->Cell_Rendered($this->staffstaff_id, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// customercustomer_id
			$currentValue = $this->customercustomer_id->CurrentValue;
			$viewValue = &$this->customercustomer_id->ViewValue;
			$viewAttrs = &$this->customercustomer_id->ViewAttrs;
			$cellAttrs = &$this->customercustomer_id->CellAttrs;
			$hrefValue = &$this->customercustomer_id->HrefValue;
			$linkAttrs = &$this->customercustomer_id->LinkAttrs;
			$this->Cell_Rendered($this->customercustomer_id, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// statusstatus_id
			$currentValue = $this->statusstatus_id->CurrentValue;
			$viewValue = &$this->statusstatus_id->ViewValue;
			$viewAttrs = &$this->statusstatus_id->ViewAttrs;
			$cellAttrs = &$this->statusstatus_id->CellAttrs;
			$hrefValue = &$this->statusstatus_id->HrefValue;
			$linkAttrs = &$this->statusstatus_id->LinkAttrs;
			$this->Cell_Rendered($this->statusstatus_id, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// customer_id
			$currentValue = $this->customer_id->CurrentValue;
			$viewValue = &$this->customer_id->ViewValue;
			$viewAttrs = &$this->customer_id->ViewAttrs;
			$cellAttrs = &$this->customer_id->CellAttrs;
			$hrefValue = &$this->customer_id->HrefValue;
			$linkAttrs = &$this->customer_id->LinkAttrs;
			$this->Cell_Rendered($this->customer_id, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// Useruser_id
			$currentValue = $this->Useruser_id->CurrentValue;
			$viewValue = &$this->Useruser_id->ViewValue;
			$viewAttrs = &$this->Useruser_id->ViewAttrs;
			$cellAttrs = &$this->Useruser_id->CellAttrs;
			$hrefValue = &$this->Useruser_id->HrefValue;
			$linkAttrs = &$this->Useruser_id->LinkAttrs;
			$this->Cell_Rendered($this->Useruser_id, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// reg_date
			$currentValue = $this->reg_date->CurrentValue;
			$viewValue = &$this->reg_date->ViewValue;
			$viewAttrs = &$this->reg_date->ViewAttrs;
			$cellAttrs = &$this->reg_date->CellAttrs;
			$hrefValue = &$this->reg_date->HrefValue;
			$linkAttrs = &$this->reg_date->LinkAttrs;
			$this->Cell_Rendered($this->reg_date, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// user_id
			$currentValue = $this->user_id->CurrentValue;
			$viewValue = &$this->user_id->ViewValue;
			$viewAttrs = &$this->user_id->ViewAttrs;
			$cellAttrs = &$this->user_id->CellAttrs;
			$hrefValue = &$this->user_id->HrefValue;
			$linkAttrs = &$this->user_id->LinkAttrs;
			$this->Cell_Rendered($this->user_id, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// user_name
			$currentValue = $this->user_name->CurrentValue;
			$viewValue = &$this->user_name->ViewValue;
			$viewAttrs = &$this->user_name->ViewAttrs;
			$cellAttrs = &$this->user_name->CellAttrs;
			$hrefValue = &$this->user_name->HrefValue;
			$linkAttrs = &$this->user_name->LinkAttrs;
			$this->Cell_Rendered($this->user_name, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// user_pass
			$currentValue = $this->user_pass->CurrentValue;
			$viewValue = &$this->user_pass->ViewValue;
			$viewAttrs = &$this->user_pass->ViewAttrs;
			$cellAttrs = &$this->user_pass->CellAttrs;
			$hrefValue = &$this->user_pass->HrefValue;
			$linkAttrs = &$this->user_pass->LinkAttrs;
			$this->Cell_Rendered($this->user_pass, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// user_email
			$currentValue = $this->user_email->CurrentValue;
			$viewValue = &$this->user_email->ViewValue;
			$viewAttrs = &$this->user_email->ViewAttrs;
			$cellAttrs = &$this->user_email->CellAttrs;
			$hrefValue = &$this->user_email->HrefValue;
			$linkAttrs = &$this->user_email->LinkAttrs;
			$this->Cell_Rendered($this->user_email, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// user_add
			$currentValue = $this->user_add->CurrentValue;
			$viewValue = &$this->user_add->ViewValue;
			$viewAttrs = &$this->user_add->ViewAttrs;
			$cellAttrs = &$this->user_add->CellAttrs;
			$hrefValue = &$this->user_add->HrefValue;
			$linkAttrs = &$this->user_add->LinkAttrs;
			$this->Cell_Rendered($this->user_add, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// user_phone
			$currentValue = $this->user_phone->CurrentValue;
			$viewValue = &$this->user_phone->ViewValue;
			$viewAttrs = &$this->user_phone->ViewAttrs;
			$cellAttrs = &$this->user_phone->CellAttrs;
			$hrefValue = &$this->user_phone->HrefValue;
			$linkAttrs = &$this->user_phone->LinkAttrs;
			$this->Cell_Rendered($this->user_phone, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// user_sec_ques
			$currentValue = $this->user_sec_ques->CurrentValue;
			$viewValue = &$this->user_sec_ques->ViewValue;
			$viewAttrs = &$this->user_sec_ques->ViewAttrs;
			$cellAttrs = &$this->user_sec_ques->CellAttrs;
			$hrefValue = &$this->user_sec_ques->HrefValue;
			$linkAttrs = &$this->user_sec_ques->LinkAttrs;
			$this->Cell_Rendered($this->user_sec_ques, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// user_sec_ans
			$currentValue = $this->user_sec_ans->CurrentValue;
			$viewValue = &$this->user_sec_ans->ViewValue;
			$viewAttrs = &$this->user_sec_ans->ViewAttrs;
			$cellAttrs = &$this->user_sec_ans->CellAttrs;
			$hrefValue = &$this->user_sec_ans->HrefValue;
			$linkAttrs = &$this->user_sec_ans->LinkAttrs;
			$this->Cell_Rendered($this->user_sec_ans, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// companycompany_id
			$currentValue = $this->companycompany_id->CurrentValue;
			$viewValue = &$this->companycompany_id->ViewValue;
			$viewAttrs = &$this->companycompany_id->ViewAttrs;
			$cellAttrs = &$this->companycompany_id->CellAttrs;
			$hrefValue = &$this->companycompany_id->HrefValue;
			$linkAttrs = &$this->companycompany_id->LinkAttrs;
			$this->Cell_Rendered($this->companycompany_id, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);

			// otp
			$currentValue = $this->otp->CurrentValue;
			$viewValue = &$this->otp->ViewValue;
			$viewAttrs = &$this->otp->ViewAttrs;
			$cellAttrs = &$this->otp->CellAttrs;
			$hrefValue = &$this->otp->HrefValue;
			$linkAttrs = &$this->otp->LinkAttrs;
			$this->Cell_Rendered($this->otp, $currentValue, $viewValue, $viewAttrs, $cellAttrs, $hrefValue, $linkAttrs);
		}

		// Call Row_Rendered event
		$this->Row_Rendered();
		$this->setupFieldCount();
	}

	// Accummulate grand summary
	protected function accumulateGrandSummary()
	{
		$this->TotalCount++;
		$cntgs = count($this->GrandSummaries);
		for ($iy = 1; $iy < $cntgs; $iy++) {
			if ($this->Columns[$iy][0]) {
				$valwrk = $this->Values[$iy];
				if ($valwrk === NULL || !is_numeric($valwrk)) {
					if (!$this->Columns[$iy][1])
						$this->GrandCounts[$iy]++;
				} else {
					if (!$this->Columns[$iy][1] || $valwrk <> 0) {
						$this->GrandCounts[$iy]++;
						$this->GrandSummaries[$iy] += $valwrk;
						if ($this->GrandMinimums[$iy] === NULL) {
							$this->GrandMinimums[$iy] = $valwrk;
							$this->GrandMaximums[$iy] = $valwrk;
						} else {
							if ($this->GrandMinimums[$iy] > $valwrk)
								$this->GrandMinimums[$iy] = $valwrk;
							if ($this->GrandMaximums[$iy] < $valwrk)
								$this->GrandMaximums[$iy] = $valwrk;
						}
					}
				}
			}
		}
	}

	// Load group db values if necessary
	protected function loadGroupDbValues()
	{
		$conn = &$this->getConnection();
	}

	// Set up popup
	protected function setupPopup()
	{
		global $ReportLanguage;
		$conn = &$this->getConnection();
		if ($this->DrillDown)
			return;

		// Process post back form
		if (IsPost()) {
			$name = Post("popup", ""); // Get popup form name
			if ($name <> "") {
				$arValues = Post("sel_$name");
				$cntValues = is_array($arValues) ? count($arValues) : 0;
				if ($cntValues > 0) {
					if (trim($arValues[0]) == "") // Select all
						$arValues = INIT_VALUE;
					$this->PopupName = $name;
					if (IsAdvancedFilterValue($arValues) || $arValues == INIT_VALUE)
						$this->PopupValue = $arValues;
					if (!MatchedArray($arValues, @$_SESSION["sel_$name"])) {
						if ($this->hasSessionFilterValues($name))
							$this->ExpiredExtendedFilter = $name; // Clear extended filter for this field
					}
					$_SESSION["sel_$name"] = $arValues;
					$_SESSION["rf_$name"] = Post("rf_$name", "");
					$_SESSION["rt_$name"] = Post("rt_$name", "");
					$this->resetPager();
				}
			}

		// Get 'reset' command
		} elseif (Get("cmd") !== NULL) {
			$cmd = Get("cmd");
			if (SameText($cmd, "reset")) {
				$this->clearSessionSelection("app_date");
				$this->resetPager();
			}
		}

		// Load selection criteria to array
		// Get app_date selected values

		if (is_array(@$_SESSION["sel__user_report_app_date"])) {
			$this->loadSelectionFromSession("app_date");
		} elseif (@$_SESSION["sel__user_report_app_date"] == INIT_VALUE) { // Select all
			$this->app_date->SelectionList = "";
		}
	}

	// Setup field count
	protected function setupFieldCount()
	{
		$this->GroupColumnCount = 0;
		$this->SubGroupColumnCount = 0;
		$this->DetailColumnCount = 0;
		if ($this->appointment_id->Visible)
			$this->DetailColumnCount += 1;
		if ($this->app_date->Visible)
			$this->DetailColumnCount += 1;
		if ($this->app_time->Visible)
			$this->DetailColumnCount += 1;
		if ($this->Vehicle_rto_number->Visible)
			$this->DetailColumnCount += 1;
		if ($this->staffstaff_id->Visible)
			$this->DetailColumnCount += 1;
		if ($this->customercustomer_id->Visible)
			$this->DetailColumnCount += 1;
		if ($this->statusstatus_id->Visible)
			$this->DetailColumnCount += 1;
		if ($this->customer_id->Visible)
			$this->DetailColumnCount += 1;
		if ($this->Useruser_id->Visible)
			$this->DetailColumnCount += 1;
		if ($this->reg_date->Visible)
			$this->DetailColumnCount += 1;
		if ($this->user_id->Visible)
			$this->DetailColumnCount += 1;
		if ($this->user_name->Visible)
			$this->DetailColumnCount += 1;
		if ($this->user_pass->Visible)
			$this->DetailColumnCount += 1;
		if ($this->user_email->Visible)
			$this->DetailColumnCount += 1;
		if ($this->user_add->Visible)
			$this->DetailColumnCount += 1;
		if ($this->user_phone->Visible)
			$this->DetailColumnCount += 1;
		if ($this->user_sec_ques->Visible)
			$this->DetailColumnCount += 1;
		if ($this->user_sec_ans->Visible)
			$this->DetailColumnCount += 1;
		if ($this->companycompany_id->Visible)
			$this->DetailColumnCount += 1;
		if ($this->otp->Visible)
			$this->DetailColumnCount += 1;
	}

	// Set up Breadcrumb
	protected function setupBreadcrumb()
	{
		global $Breadcrumb;
		$Breadcrumb = new Breadcrumb();
		$url = substr(CurrentUrl(), strrpos(CurrentUrl(), "/") + 1);
		$url = preg_replace('/\?cmd=reset(all){0,1}$/i', "", $url); // Remove cmd=reset / cmd=resetall
		$Breadcrumb->add("rpt", $this->TableVar, $url, "", $this->TableVar, TRUE);
	}

	// Set up export options (extended)
	protected function setupExportOptionsExt()
	{
		global $ReportLanguage, $ReportOptions;
		$reportTypes = $ReportOptions["ReportTypes"];
		$ReportOptions["ReportTypes"] = $reportTypes;
	}

	// Export to PDF
	public function exportPdf($html)
	{
		$folder = ReportParam("folder", "");
		$fileName = ReportParam("filename", "");
		$responseType = ReportParam("responsetype", "");
		$saveToFile = "";
		if ($folder <> "" && $fileName <> "" && ($responseType == "json" || $responseType == "file" && REPORT_SAVE_OUTPUT_ON_SERVER)) {
			$fileName = str_replace(".pdf", ".html", $fileName); // Handle as html
		 	SaveFile(ServerMapPath($folder), $fileName, $html);
			$saveToFile = UploadPath(FALSE, $folder) . $fileName;
		}
		if ($saveToFile == "" || $responseType == "file")
			Write($html);
		DeleteTempImages($html);
		return $saveToFile;
	}

	// Set up starting group
	protected function setupStartGroup()
	{

		// Exit if no groups
		if ($this->DisplayGroups == 0)
			return;
		$startGrp = ReportParam(TABLE_START_GROUP, "");
		$pageNo = ReportParam("pageno", "");

		// Check for a 'start' parameter
		if ($startGrp != "") {
			$this->StartGroup = $startGrp;
			$this->setStartGroup($this->StartGroup);
		} elseif ($pageNo != "") {
			if (is_numeric($pageNo)) {
				$this->StartGroup = ($pageNo - 1) * $this->DisplayGroups + 1;
				if ($this->StartGroup <= 0) {
					$this->StartGroup = 1;
				} elseif ($this->StartGroup >= intval(($this->TotalGroups - 1) / $this->DisplayGroups) * $this->DisplayGroups + 1) {
					$this->StartGroup = intval(($this->TotalGroups - 1) / $this->DisplayGroups) * $this->DisplayGroups + 1;
				}
				$this->setStartGroup($this->StartGroup);
			} else {
				$this->StartGroup = $this->getStartGroup();
			}
		} else {
			$this->StartGroup = $this->getStartGroup();
		}

		// Check if correct start group counter
		if (!is_numeric($this->StartGroup) || $this->StartGroup == "") { // Avoid invalid start group counter
			$this->StartGroup = 1; // Reset start group counter
			$this->setStartGroup($this->StartGroup);
		} elseif (intval($this->StartGroup) > intval($this->TotalGroups)) { // Avoid starting group > total groups
			$this->StartGroup = intval(($this->TotalGroups - 1) / $this->DisplayGroups) * $this->DisplayGroups + 1; // Point to last page first group
			$this->setStartGroup($this->StartGroup);
		} elseif (($this->StartGroup-1) % $this->DisplayGroups <> 0) {
			$this->StartGroup = intval(($this->StartGroup - 1) / $this->DisplayGroups) * $this->DisplayGroups + 1; // Point to page boundary
			$this->setStartGroup($this->StartGroup);
		}
	}

	// Reset pager
	protected function resetPager()
	{

		// Reset start position (reset command)
		$this->StartGroup = 1;
		$this->setStartGroup($this->StartGroup);
	}

	// Set up number of groups displayed per page
	protected function setupDisplayGroups()
	{
		if (ReportParam(TABLE_GROUP_PER_PAGE) !== NULL) {
			$wrk = ReportParam(TABLE_GROUP_PER_PAGE);
			if (is_numeric($wrk)) {
				$this->DisplayGroups = intval($wrk);
			} else {
				if (strtoupper($wrk) == "ALL") { // Display all groups
					$this->DisplayGroups = -1;
				} else {
					$this->DisplayGroups = 3; // Non-numeric, load default
				}
			}
			$this->setGroupPerPage($this->DisplayGroups); // Save to session

			// Reset start position (reset command)
			$this->StartGroup = 1;
			$this->setStartGroup($this->StartGroup);
		} else {
			if ($this->getGroupPerPage() <> "") {
				$this->DisplayGroups = $this->getGroupPerPage(); // Restore from session
			} else {
				$this->DisplayGroups = 3; // Load default
			}
		}
	}

	// Get sort parameters based on sort links clicked
	protected function getSort()
	{
		if ($this->DrillDown)
			return "";
		$resetSort = ReportParam("cmd") === "resetsort";
		$orderBy = ReportParam("order", "");
		$orderType = ReportParam("ordertype", "");

		// Check for a resetsort command
		if ($resetSort) {
			$this->setOrderBy("");
			$this->setStartGroup(1);
			$this->appointment_id->setSort("");
			$this->app_date->setSort("");
			$this->app_time->setSort("");
			$this->Vehicle_rto_number->setSort("");
			$this->staffstaff_id->setSort("");
			$this->customercustomer_id->setSort("");
			$this->statusstatus_id->setSort("");
			$this->customer_id->setSort("");
			$this->Useruser_id->setSort("");
			$this->reg_date->setSort("");
			$this->user_id->setSort("");
			$this->user_name->setSort("");
			$this->user_pass->setSort("");
			$this->user_email->setSort("");
			$this->user_add->setSort("");
			$this->user_phone->setSort("");
			$this->user_sec_ques->setSort("");
			$this->user_sec_ans->setSort("");
			$this->companycompany_id->setSort("");
			$this->otp->setSort("");

		// Check for an Order parameter
		} elseif ($orderBy <> "") {
			$this->CurrentOrder = $orderBy;
			$this->CurrentOrderType = $orderType;
			$sortSql = $this->sortSql();
			$this->setOrderBy($sortSql);
			$this->setStartGroup(1);
		}
		return $this->getOrderBy();
	}

	// Return extended filter
	protected function getExtendedFilter()
	{
		global $FormError;
		$filter = "";
		if ($this->DrillDown)
			return "";
		$postBack = IsPost();
		$restoreSession = TRUE;
		$setupFilter = FALSE;

		// Reset extended filter if filter changed
		if ($postBack) {

			// Clear extended filter for field app_date
			if ($this->ExpiredExtendedFilter == "_user_report_app_date")
				$this->setSessionFilterValues("", "=", "AND", "", "=", "app_date");

		// Reset search command
		} elseif (Get("cmd", "") == "reset") {

			// Load default values
			$this->setSessionFilterValues($this->app_date->AdvancedSearch->SearchValue, $this->app_date->AdvancedSearch->SearchOperator, $this->app_date->AdvancedSearch->SearchCondition, $this->app_date->AdvancedSearch->SearchValue2, $this->app_date->AdvancedSearch->SearchOperator2, "app_date"); // Field app_date

			//$setupFilter = TRUE; // No need to set up, just use default
		} else {
			$restoreSession = !$this->SearchCommand;

			// Field app_date
			if ($this->getFilterValues($this->app_date)) {
				$setupFilter = TRUE;
			}
			if (!$this->validateForm()) {
				$this->setFailureMessage($FormError);
				return $filter;
			}
		}

		// Restore session
		if ($restoreSession) {
			$this->getSessionFilterValues($this->app_date); // Field app_date
		}

		// Call page filter validated event
		$this->Page_FilterValidated();

		// Build SQL
		$this->buildExtendedFilter($this->app_date, $filter, FALSE, TRUE); // Field app_date

		// Save parms to session
		$this->setSessionFilterValues($this->app_date->AdvancedSearch->SearchValue, $this->app_date->AdvancedSearch->SearchOperator, $this->app_date->AdvancedSearch->SearchCondition, $this->app_date->AdvancedSearch->SearchValue2, $this->app_date->AdvancedSearch->SearchOperator2, "app_date"); // Field app_date

		// Setup filter
		if ($setupFilter) {

			// Field app_date
			$wrk = "";
			$this->buildExtendedFilter($this->app_date, $wrk);
			LoadSelectionFromFilter($this->app_date, $wrk, $this->app_date->SelectionList);
			$_SESSION["sel__user_report_app_date"] = ($this->app_date->SelectionList == "") ? INIT_VALUE : $this->app_date->SelectionList;
		}
		return $filter;
	}

	// Build dropdown filter
	protected function buildDropDownFilter(&$fld, &$filterClause, $fldOpr, $default = FALSE, $saveFilter = FALSE)
	{
		$fldVal = ($default) ? $fld->DefaultDropDownValue : $fld->DropDownValue;
		$sql = "";
		if (is_array($fldVal)) {
			foreach ($fldVal as $val) {
				$wrk = $this->getDropDownFilter($fld, $val, $fldOpr);

				// Call Page Filtering event
				if (!StartsString("@@", $val))
					$this->Page_Filtering($fld, $wrk, "dropdown", $fldOpr, $val);
				if ($wrk <> "") {
					if ($sql <> "")
						$sql .= " OR " . $wrk;
					else
						$sql = $wrk;
				}
			}
		} else {
			$sql = $this->getDropDownFilter($fld, $fldVal, $fldOpr);

			// Call Page Filtering event
			if (!StartsString("@@", $fldVal))
				$this->Page_Filtering($fld, $sql, "dropdown", $fldOpr, $fldVal);
		}
		if ($sql <> "") {
			AddFilter($filterClause, $sql);
			if ($saveFilter) $fld->CurrentFilter = $sql;
		}
	}

	// Get dropdown filter
	protected function getDropDownFilter(&$fld, $fldVal, $fldOpr)
	{
		$fldName = $fld->Name;
		$fldExpression = $fld->Expression;
		$fldDataType = $fld->DataType;
		$fldDelimiter = $fld->Delimiter;
		$fldVal = strval($fldVal);
		if ($fldOpr == "") $fldOpr = "=";
		$wrk = "";
		if (SameString($fldVal, NULL_VALUE)) {
			$wrk = $fldExpression . " IS NULL";
		} elseif (SameString($fldVal, NOT_NULL_VALUE)) {
			$wrk = $fldExpression . " IS NOT NULL";
		} elseif (SameString($fldVal, EMPTY_VALUE)) {
			$wrk = $fldExpression . " = ''";
		} elseif (SameString($fldVal, ALL_VALUE)) {
			$wrk = "1 = 1";
		} else {
			if (StartsString("@@", $fldVal)) {
				$wrk = $this->getCustomFilter($fld, $fldVal, $this->Dbid);
			} elseif ($fldDelimiter <> "" && trim($fldVal) <> "" && ($fldDataType == DATATYPE_STRING || $fldDataType == DATATYPE_MEMO)) {
				$wrk = GetMultiValueSearchSql($fldExpression, trim($fldVal), $this->Dbid);
			} else {
				if ($fldVal <> "" && $fldVal <> INIT_VALUE) {
					if ($fldDataType == DATATYPE_DATE && $fldOpr <> "") {
						$wrk = GetDateFilterSql($fldExpression, $fldOpr, $fldVal, $fldDataType, $this->Dbid);
					} else {
						$wrk = GetFilterSql($fldOpr, $fldVal, $fldDataType, $this->Dbid);
						if ($wrk <> "") $wrk = $fldExpression . $wrk;
					}
				}
			}
		}
		return $wrk;
	}

	// Get custom filter
	protected function getCustomFilter(&$fld, $fldVal, $dbid = 0)
	{
		$wrk = "";
		if (is_array($fld->AdvancedFilters)) {
			foreach ($fld->AdvancedFilters as $filter) {
				if ($filter->ID == $fldVal && $filter->Enabled) {
					$fldExpr = $fld->Expression;
					$fn = $filter->FunctionName;
					$wrkid = StartsString("@@", $filter->ID) ? substr($filter->ID, 2) : $filter->ID;
					if ($fn <> "") {
						$fn = PROJECT_NAMESPACE . $fn;
						$wrk = $fn($fldExpr, $dbid);
					} else
						$wrk = "";
					$this->Page_Filtering($fld, $wrk, "custom", $wrkid);
					break;
				}
			}
		}
		return $wrk;
	}

	// Build extended filter
	protected function buildExtendedFilter(&$fld, &$filterClause, $default = FALSE, $saveFilter = FALSE)
	{
		$wrk = GetExtendedFilter($fld, $default, $this->Dbid);
		if (!$default)
			$this->Page_Filtering($fld, $wrk, "extended", $fld->AdvancedSearch->SearchOperator, $fld->AdvancedSearch->SearchValue, $fld->AdvancedSearch->SearchCondition, $fld->AdvancedSearch->SearchOperator2, $fld->AdvancedSearch->SearchValue2);
		if ($wrk <> "") {
			AddFilter($filterClause, $wrk);
			if ($saveFilter) $fld->CurrentFilter = $wrk;
		}
	}

	// Get drop down value from querystring
	protected function getDropDownValue(&$fld)
	{
		$parm = substr($fld->FieldVar, 2);
		if (IsPost())
			return FALSE; // Skip post back
		$opr = Get("z_$parm");
		if ($opr !== NULL)
			$fld->AdvancedSearch->SearchOperator = $opr;
		$val = Get("x_$parm");
		if ($val !== NULL) {
			if ($fld->isMultiSelect() && !is_array($val)) // Split values for modal lookup
				$fld->DropDownValue = explode(LOOKUP_FILTER_VALUE_SEPARATOR, $val);
			else
				$fld->DropDownValue = $val;
			return TRUE;
		}
		return FALSE;
	}

	// Get filter values from querystring
	protected function getFilterValues(&$fld)
	{
		$parm = substr($fld->FieldVar, 2);
		if (IsPost())
			return; // Skip post back
		$got = FALSE;
		if (Get("x_$parm") !== NULL) {
			$fld->AdvancedSearch->SearchValue = Get("x_$parm");
			$got = TRUE;
		}
		if (Get("z_$parm") !== NULL) {
			$fld->AdvancedSearch->SearchOperator = Get("z_$parm");
			$got = TRUE;
		}
		if (Get("v_$parm") !== NULL) {
			$fld->AdvancedSearch->SearchCondition = Get("v_$parm");
			$got = TRUE;
		}
		if (Get("y_$parm") !== NULL) {
			$fld->AdvancedSearch->SearchValue2 = Get("y_$parm");
			$got = TRUE;
		}
		if (Get("w_$parm") !== NULL) {
			$fld->AdvancedSearch->SearchOperator2 = Get("w_$parm");
			$got = TRUE;
		}
		return $got;
	}

	// Set default ext filter
	protected function setDefaultExtFilter(&$fld, $so1, $sv1, $sc, $so2, $sv2)
	{
		$fld->AdvancedSearch->SearchValueDefault = $sv1; // Default ext filter value 1
		$fld->AdvancedSearch->SearchValue2Default = $sv2; // Default ext filter value 2 (if operator 2 is enabled)
		$fld->AdvancedSearch->SearchOperatorDefault = $so1; // Default search operator 1
		$fld->AdvancedSearch->SearchOperator2Default = $so2; // Default search operator 2 (if operator 2 is enabled)
		$fld->AdvancedSearch->SearchConditionDefault = $sc; // Default search condition (if operator 2 is enabled)
	}

	// Apply default ext filter
	protected function applyDefaultExtFilter(&$fld)
	{
		$fld->AdvancedSearch->SearchValue = $fld->AdvancedSearch->SearchValueDefault;
		$fld->AdvancedSearch->SearchValue2 = $fld->AdvancedSearch->SearchValue2Default;
		$fld->AdvancedSearch->SearchOperator = $fld->AdvancedSearch->SearchOperatorDefault;
		$fld->AdvancedSearch->SearchOperator2 = $fld->AdvancedSearch->SearchOperator2Default;
		$fld->AdvancedSearch->SearchCondition = $fld->AdvancedSearch->SearchConditionDefault;
	}

	// Check if Text Filter applied
	protected function textFilterApplied(&$fld)
	{
		return (strval($fld->AdvancedSearch->SearchValue) <> strval($fld->AdvancedSearch->SearchValueDefault) ||
			strval($fld->AdvancedSearch->SearchValue2) <> strval($fld->AdvancedSearch->SearchValue2Default) ||
			(strval($fld->AdvancedSearch->SearchValue) <> "" &&
				strval($fld->AdvancedSearch->SearchOperator) <> strval($fld->AdvancedSearch->SearchOperatorDefault)) ||
			(strval($fld->AdvancedSearch->SearchValue2) <> "" &&
				strval($fld->AdvancedSearch->SearchOperator2) <> strval($fld->AdvancedSearch->SearchOperator2Default)) ||
			strval($fld->AdvancedSearch->SearchCondition) <> strval($fld->AdvancedSearch->SearchConditionDefault));
	}

	// Check if Non-Text Filter applied
	protected function nonTextFilterApplied(&$fld)
	{
		if (is_array($fld->DropDownValue)) {
			if (is_array($fld->DefaultDropDownValue)) {
				if (count($fld->DefaultDropDownValue) <> count($fld->DropDownValue))
					return TRUE;
				else
					return (count(array_diff($fld->DefaultDropDownValue, $fld->DropDownValue)) <> 0);
			} else {
				return TRUE;
			}
		} else {
			if (is_array($fld->DefaultDropDownValue))
				return TRUE;
			else
				$v1 = strval($fld->DefaultDropDownValue);
			if ($v1 == INIT_VALUE)
				$v1 = "";
			$v2 = strval($fld->DropDownValue);
			if ($v2 == INIT_VALUE || $v2 == ALL_VALUE)
				$v2 = "";
			return ($v1 <> $v2);
		}
	}

	// Get dropdown value from session
	protected function getSessionDropDownValue(&$fld)
	{
		$parm = substr($fld->FieldVar, 2);
		$this->getSessionValue($fld->DropDownValue, 'x__user_report_' . $parm);
		$this->getSessionValue($fld->AdvancedSearch->SearchOperator, 'z__user_report_' . $parm);
	}

	// Get filter values from session
	protected function getSessionFilterValues(&$fld)
	{
		$parm = substr($fld->FieldVar, 2);
		$this->getSessionValue($fld->AdvancedSearch->SearchValue, 'x__user_report_' . $parm);
		$this->getSessionValue($fld->AdvancedSearch->SearchOperator, 'z__user_report_' . $parm);
		$this->getSessionValue($fld->AdvancedSearch->SearchCondition, 'v__user_report_' . $parm);
		$this->getSessionValue($fld->AdvancedSearch->SearchValue2, 'y__user_report_' . $parm);
		$this->getSessionValue($fld->AdvancedSearch->SearchOperator2, 'w__user_report_' . $parm);
	}

	// Get value from session
	protected function getSessionValue(&$sv, $sn)
	{
		if (array_key_exists($sn, $_SESSION))
			$sv = $_SESSION[$sn];
	}

	// Set dropdown value to session
	protected function setSessionDropDownValue($sv, $so, $parm)
	{
		$_SESSION['x__user_report_' . $parm] = $sv;
		$_SESSION['z__user_report_' . $parm] = $so;
	}

	// Set filter values to session
	protected function setSessionFilterValues($sv1, $so1, $sc, $sv2, $so2, $parm)
	{
		$_SESSION['x__user_report_' . $parm] = $sv1;
		$_SESSION['z__user_report_' . $parm] = $so1;
		$_SESSION['v__user_report_' . $parm] = $sc;
		$_SESSION['y__user_report_' . $parm] = $sv2;
		$_SESSION['w__user_report_' . $parm] = $so2;
	}

	// Check if has session filter values
	protected function hasSessionFilterValues($parm)
	{
		return (@$_SESSION['x_' . $parm] <> "" && @$_SESSION['x_' . $parm] <> INIT_VALUE ||
			@$_SESSION['x_' . $parm] <> "" && @$_SESSION['x_' . $parm] <> INIT_VALUE ||
			@$_SESSION['y_' . $parm] <> "" && @$_SESSION['y_' . $parm] <> INIT_VALUE);
	}

	// Dropdown filter exist
	protected function dropDownFilterExist(&$fld, $fldOpr)
	{
		$wrk = "";
		$this->buildDropDownFilter($fld, $wrk, $fldOpr);
		return ($wrk <> "");
	}

	// Extended filter exist
	protected function extendedFilterExist(&$fld)
	{
		$extWrk = "";
		$this->buildExtendedFilter($fld, $extWrk);
		return ($extWrk <> "");
	}

	// Validate form
	protected function validateForm()
	{
		global $ReportLanguage, $FormError;

		// Initialize form error message
		$FormError = "";

		// Check if validation required
		if (!SERVER_VALIDATE)
			return ($FormError == "");
		if (!CheckDate($this->app_date->AdvancedSearch->SearchValue)) {
			AddMessage($FormError, $this->app_date->errorMessage());
		}

		// Return validate result
		$validateForm = ($FormError == "");

		// Call Form_CustomValidate event
		$formCustomError = "";
		$validateForm = $validateForm && $this->Form_CustomValidate($formCustomError);
		if ($formCustomError <> "") {
			$FormError .= ($FormError <> "") ? "<p>&nbsp;</p>" : "";
			$FormError .= $formCustomError;
		}
		return $validateForm;
	}

	// Clear selection stored in session
	protected function clearSessionSelection($parm)
	{
		$_SESSION["sel__user_report_$parm"] = "";
		$_SESSION["rf__user_report_$parm"] = "";
		$_SESSION["rt__user_report_$parm"] = "";
	}

	// Load selection from session
	protected function loadSelectionFromSession($parm)
	{
		foreach ($this->fields as $fld) {
			if ($fld->Param == $parm) {
				$fld->SelectionList = @$_SESSION["sel__user_report_$parm"];
				$fld->RangeFrom = @$_SESSION["rf__user_report_$parm"];
				$fld->RangeTo = @$_SESSION["rt__user_report_$parm"];
				break;
			}
		}
	}

	// Load default value for filters
	protected function loadDefaultFilters()
	{

		/**
		* Set up default values for non Text filters
		*/

		/**
		* Set up default values for extended filters
		* function setDefaultExtFilter(&$fld, $so1, $sv1, $sc, $so2, $sv2)
		* Parameters:
		* $fld - Field object
		* $so1 - Default search operator 1
		* $sv1 - Default ext filter value 1
		* $sc - Default search condition (if operator 2 is enabled)
		* $so2 - Default search operator 2 (if operator 2 is enabled)
		* $sv2 - Default ext filter value 2 (if operator 2 is enabled)
		*/
		// Field app_date

		$this->setDefaultExtFilter($this->app_date, "=", NULL, 'AND', "=", NULL);
		if (!$this->SearchCommand)
			$this->applyDefaultExtFilter($this->app_date);
		$wrk = "";
		$this->buildExtendedFilter($this->app_date, $wrk, TRUE);
		LoadSelectionFromFilter($this->app_date, $wrk, $this->app_date->DefaultSelectionList);
		if (!$this->SearchCommand)
			$this->app_date->SelectionList = $this->app_date->DefaultSelectionList;

		/**
		* Set up default values for popup filters
		*/
		// Field app_date
		// $this->app_date->DefaultSelectionList = ["val1", "val2"];

	}

	// Check if filter applied
	protected function checkFilter()
	{

		// Check app_date text filter
		if ($this->textFilterApplied($this->app_date))
			return TRUE;

		// Check app_date popup filter
		if (!MatchedArray($this->app_date->DefaultSelectionList, $this->app_date->SelectionList))
			return TRUE;
		return FALSE;
	}

	// Show list of filters
	public function showFilterList($showDate = FALSE)
	{
		global $ReportLanguage;

		// Initialize
		$filterList = "";
		$captionClass = $this->isExport("email") ? "ew-filter-caption-email" : "ew-filter-caption";
		$captionSuffix = $this->isExport("email") ? ": " : "";

		// Field app_date
		$extWrk = "";
		$wrk = "";
		$this->buildExtendedFilter($this->app_date, $extWrk);
		if (is_array($this->app_date->SelectionList))
			$wrk = JoinArray($this->app_date->SelectionList, ", ", DATATYPE_DATE, 0, $this->Dbid);
		$filter = "";
		if ($extWrk <> "")
			$filter .= "<span class=\"ew-filter-value\">$extWrk</span>";
		elseif ($wrk <> "")
			$filter .= "<span class=\"ew-filter-value\">$wrk</span>";
		if ($filter <> "")
			$filterList .= "<div><span class=\"" . $captionClass . "\">" . $this->app_date->caption() . "</span>" . $captionSuffix . $filter . "</div>";
		$divdataclass = "";

		// Show Filters
		if ($filterList <> "" || $showDate) {
			$message = "<div" . $divdataclass . "><div id=\"ew-filter-list\" class=\"alert alert-info d-table\">";
			if ($showDate)
				$message .= "<div id=\"ew-current-date\">" . $ReportLanguage->phrase("ReportGeneratedDate") . FormatDateTime(date("Y-m-d H:i:s"), 1) . "</div>";
			if ($filterList <> "")
				$message .= "<div id=\"ew-current-filters\">" . $ReportLanguage->phrase("CurrentFilters") . "</div>" . $filterList;
			$message .= "</div></div>";
			$this->Message_Showing($message, "");
			Write($message);
		}
	}

	// Get list of filters
	public function getFilterList()
	{

		// Initialize
		$filterList = "";

		// Field app_date
		$wrk = "";
		if ($this->app_date->AdvancedSearch->SearchValue <> "" || $this->app_date->AdvancedSearch->SearchValue2 <> "") {
			$wrk = "\"x_app_date\":\"" . JsEncode($this->app_date->AdvancedSearch->SearchValue) . "\"," .
				"\"z_app_date\":\"" . JsEncode($this->app_date->AdvancedSearch->SearchOperator) . "\"," .
				"\"v_app_date\":\"" . JsEncode($this->app_date->AdvancedSearch->SearchCondition) . "\"," .
				"\"y_app_date\":\"" . JsEncode($this->app_date->AdvancedSearch->SearchValue2) . "\"," .
				"\"w_app_date\":\"" . JsEncode($this->app_date->AdvancedSearch->SearchOperator2) . "\"";
		}
		if ($wrk == "") {
			$wrk = ($this->app_date->SelectionList <> INIT_VALUE) ? $this->app_date->SelectionList : "";
			if (is_array($wrk))
				$wrk = implode("||", $wrk);
			if ($wrk <> "")
				$wrk = "\"sel_app_date\":\"" . JsEncode($wrk) . "\"";
		}
		if ($wrk <> "") {
			if ($filterList <> "") $filterList .= ",";
			$filterList .= $wrk;
		}

		// Return filter list in json
		if ($filterList <> "")
			return "{\"data\":{" . $filterList . "}}";
		else
			return "null";
	}

	// Restore list of filters
	protected function restoreFilterList()
	{

		// Return if not reset filter
		if (Post("cmd", "") <> "resetfilter")
			return FALSE;
		$filter = json_decode(Post("filter", ""), TRUE);
		return $this->setupFilterList($filter);
	}

	// Setup list of filters
	protected function setupFilterList($filter)
	{
		if (!is_array($filter))
			return FALSE;

		// Field app_date
		$restoreFilter = FALSE;
		if (array_key_exists("x_app_date", $filter) || array_key_exists("z_app_date", $filter) ||
			array_key_exists("v_app_date", $filter) ||
			array_key_exists("y_app_date", $filter) || array_key_exists("w_app_date", $filter)) {
			$this->setSessionFilterValues(@$filter["x_app_date"], @$filter["z_app_date"], @$filter["v_app_date"], @$filter["y_app_date"], @$filter["w_app_date"], "app_date");
			$restoreFilter = TRUE;
		}
		if (array_key_exists("sel_app_date", $filter)) {
			$wrk = $filter["sel_app_date"];
			$wrk = explode("||", $wrk);
			$this->app_date->SelectionList = $wrk;
			$_SESSION["sel__user_report_app_date"] = $wrk;
			$this->setSessionFilterValues("", "=", "AND", "", "=", "app_date"); // Clear extended filter
			$restoreFilter = TRUE;
		}
		if (!$restoreFilter) { // Clear filter
			$this->setSessionFilterValues("", "=", "AND", "", "=", "app_date");
			$this->app_date->SelectionList = "";
			$_SESSION["sel__user_report_app_date"] = "";
		}
		return TRUE;
	}

	// Setup lookup options
	public function setupLookupOptions($fld)
	{
		if ($fld->Lookup !== NULL && $fld->Lookup->Options === NULL) {

			// No need to check any more
			$fld->Lookup->Options = [];

			// Set up lookup SQL
			switch ($fld->FieldVar) {
				default:
					$lookupFilter = "";
					break;
			}

			// Always call to Lookup->getSql so that user can setup Lookup->Options in Lookup_Selecting server event
			$sql = $fld->Lookup->getSql(FALSE, "", $lookupFilter, $this);

			// Set up lookup cache
			if ($fld->UseLookupCache && $sql <> "" && count($fld->Lookup->Options) == 0) {
				$conn = &$this->getConnection();
				$totalCnt = $this->getRecordCount($sql);
				if ($totalCnt > $fld->LookupCacheCount) // Total count > cache count, do not cache
					return;
				$rs = $conn->execute($sql);
				$ar = [];
				while ($rs && !$rs->EOF) {
					$row = &$rs->fields;

					// Render lookup
					$this->RowType == ROWTYPE_VIEW;
					$fn = $fld->Lookup->RenderViewFunc;
					$render = method_exists($this, $fn);

					// Format the field values
					$fld->setDbValue($row[1]);
					if ($render) {
						$this->$fn();
						$row[1] = $fld->ViewValue;
						$row['df'] = $row[1];
					} elseif ($fld->isEncrypt()) {
						$row[1] = $fld->CurrentValue;
					}
					$ar[strval($row[0])] = $row;
					$rs->moveNext();
				}
				if ($rs)
					$rs->close();
				$fld->Lookup->Options = $ar;
			}
		}
	}

	// Return popup filter
	protected function getPopupFilter()
	{
		$wrk = "";
		if ($this->DrillDown)
			return "";
		if (!$this->extendedFilterExist($this->app_date)) {
			if (is_array($this->app_date->SelectionList)) {
				$filter = FilterSql($this->app_date, "`app_date`", DATATYPE_DATE, $this->Dbid);

				// Call Page Filtering event
				$this->Page_Filtering($this->app_date, $filter, "popup");
				$this->app_date->CurrentFilter = $filter;
				AddFilter($wrk, $filter);
			}
		}
		return $wrk;
	}

	// Page Load event
	function Page_Load() {

		//echo "Page Load";
	}

	// Page Unload event
	function Page_Unload() {

		//echo "Page Unload";
	}

	// Message Showing event
	// $type = ''|'success'|'failure'|'warning'
	function Message_Showing(&$msg, $type) {
		if ($type == 'success') {

			//$msg = "your success message";
		} elseif ($type == 'failure') {

			//$msg = "your failure message";
		} elseif ($type == 'warning') {

			//$msg = "your warning message";
		} else {

			//$msg = "your message";
		}
	}

	// Page Render event
	function Page_Render() {

		//echo "Page Render";
	}

	// Page Data Rendering event
	function Page_DataRendering(&$header) {

		// Example:
		//$header = "your header";

	}

	// Page Data Rendered event
	function Page_DataRendered(&$footer) {

		// Example:
		//$footer = "your footer";

	}

	// Form Custom Validate event
	function Form_CustomValidate(&$CustomError) {

		// Return error message in CustomError
		return TRUE;
	}
}
?>