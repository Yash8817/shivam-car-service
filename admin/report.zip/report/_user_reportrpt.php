<?php
namespace PHPReportMaker12\project1;

// Session
if (session_status() !== PHP_SESSION_ACTIVE)
	session_start(); // Init session data

// Output buffering
ob_start();

// Autoload
include_once "rautoload.php";
?>
<?php

// Create page object
if (!isset($_user_report_rpt))
	$_user_report_rpt = new _user_report_rpt();
if (isset($Page))
	$OldPage = $Page;
$Page = &$_user_report_rpt;

// Run the page
$Page->run();

// Setup login status
SetClientVar("login", LoginStatus());
if (!$DashboardReport)
	WriteHeader(FALSE);

// Global Page Rendering event (in rusrfn*.php)
Page_Rendering();

// Page Rendering event
$Page->Page_Render();
?>
<?php if (!$DashboardReport) { ?>
<?php include_once "rheader.php" ?>
<?php } ?>
<?php if ($Page->Export == "") { ?>
<script>
currentPageID = ew.PAGE_ID = "rpt"; // Page ID
</script>
<?php } ?>
<?php if ($Page->Export == "" && !$Page->DrillDown && !$DashboardReport) { ?>
<script>

// Form object
var f_user_reportrpt = currentForm = new ew.Form("f_user_reportrpt");

// Validate method
f_user_reportrpt.validate = function() {
	if (!this.validateRequired)
		return true; // Ignore validation
	var $ = jQuery, fobj = this.getForm(), $fobj = $(fobj), elm;
		elm = this.getElements("x_app_date");
		if (elm && !ew.checkDateDef(elm.value)) {
			if (!this.onError(elm, "<?php echo JsEncode($Page->app_date->errorMessage()) ?>"))
				return false;
		}

	// Call Form Custom Validate event
	if (!this.Form_CustomValidate(fobj))
		return false;
	return true;
}

// Form_CustomValidate method
f_user_reportrpt.Form_CustomValidate = function(fobj) { // DO NOT CHANGE THIS LINE!

	// Your custom validation code here, return false if invalid.
	return true;
}
<?php if (CLIENT_VALIDATE) { ?>
f_user_reportrpt.validateRequired = true; // Uses JavaScript validation
<?php } else { ?>
f_user_reportrpt.validateRequired = false; // No JavaScript validation
<?php } ?>

// Use Ajax
f_user_reportrpt.lists["x_app_date"] = <?php echo $_user_report_rpt->app_date->Lookup->toClientList() ?>;
f_user_reportrpt.lists["x_app_date"].popupValues = <?php echo json_encode($_user_report_rpt->app_date->SelectionList) ?>;
f_user_reportrpt.lists["x_app_date"].popupOptions = <?php echo JsonEncode($_user_report_rpt->app_date->popupOptions()) ?>;
</script>
<?php } ?>
<?php if ($Page->Export == "" && !$Page->DrillDown && !$DashboardReport) { ?>
<script>

// Write your client script here, no need to add script tags.
</script>
<?php } ?>
<a id="top"></a>
<?php if ($Page->Export == "" && !$DashboardReport) { ?>
<!-- Content Container -->
<div id="ew-container" class="container-fluid ew-container">
<?php } ?>
<?php if (ReportParam("showfilter") === TRUE) { ?>
<?php $Page->showFilterList(TRUE) ?>
<?php } ?>
<div class="btn-toolbar ew-toolbar">
<?php
if (!$Page->DrillDownInPanel) {
	$Page->ExportOptions->render("body");
	$Page->SearchOptions->render("body");
	$Page->FilterOptions->render("body");
	$Page->GenerateOptions->render("body");
}
?>
</div>
<?php $Page->showPageHeader(); ?>
<?php $Page->showMessage(); ?>
<?php if ($Page->Export == "" && !$DashboardReport) { ?>
<div class="row">
<?php } ?>
<?php if ($Page->Export == "" && !$DashboardReport) { ?>
<!-- Center Container - Report -->
<div id="ew-center" class="<?php echo $_user_report_rpt->CenterContentClass ?>">
<?php } ?>
<!-- Summary Report begins -->
<?php if ($Page->Export <> "pdf") { ?>
<div id="report_summary">
<?php } ?>
<?php if ($Page->Export == "" && !$Page->DrillDown && !$DashboardReport) { ?>
<!-- Search form (begin) -->
<?php

	// Render search row
	$Page->resetAttributes();
	$Page->RowType = ROWTYPE_SEARCH;
	$Page->renderRow();
?>
<form name="f_user_reportrpt" id="f_user_reportrpt" class="form-inline ew-form ew-ext-filter-form" action="<?php echo CurrentPageName() ?>">
<?php $searchPanelClass = ($Page->Filter <> "") ? " show" : " show"; ?>
<div id="f_user_reportrpt-search-panel" class="ew-search-panel collapse<?php echo $searchPanelClass ?>">
<input type="hidden" name="cmd" value="search">
<div id="r_1" class="ew-row d-sm-flex">
<div id="c_app_date" class="ew-cell form-group">
	<label for="x_app_date" class="ew-search-caption ew-label"><?php echo $Page->app_date->caption() ?></label>
	<span class="ew-search-operator"><?php echo $ReportLanguage->phrase("="); ?><input type="hidden" name="z_app_date" id="z_app_date" value="="></span>
	<span class="control-group ew-search-field">
<?php PrependClass($Page->app_date->EditAttrs["class"], "form-control"); // PR8 ?>
<input type="text" data-table="_user_report" data-field="x_app_date" id="x_app_date" name="x_app_date" maxlength="10" placeholder="<?php echo HtmlEncode($Page->app_date->getPlaceHolder()) ?>" value="<?php echo HtmlEncode($Page->app_date->AdvancedSearch->SearchValue) ?>"<?php echo $Page->app_date->editAttributes() ?>>
</span>
</div>
</div>
<div class="ew-row d-sm-flex">
<button type="submit" name="btn-submit" id="btn-submit" class="btn btn-primary"><?php echo $ReportLanguage->phrase("Search") ?></button>
<button type="reset" name="btn-reset" id="btn-reset" class="btn hide"><?php echo $ReportLanguage->phrase("Reset") ?></button>
</div>
</div>
</form>
<script>
f_user_reportrpt.filterList = <?php echo $Page->getFilterList() ?>;
</script>
<!-- Search form (end) -->
<?php } ?>
<?php if ($Page->ShowCurrentFilter) { ?>
<?php $Page->showFilterList() ?>
<?php } ?>
<?php

// Set the last group to display if not export all
if ($Page->ExportAll && $Page->Export <> "") {
	$Page->StopGroup = $Page->TotalGroups;
} else {
	$Page->StopGroup = $Page->StartGroup + $Page->DisplayGroups - 1;
}

// Stop group <= total number of groups
if (intval($Page->StopGroup) > intval($Page->TotalGroups))
	$Page->StopGroup = $Page->TotalGroups;
$Page->RecordCount = 0;
$Page->RecordIndex = 0;

// Get first row
if ($Page->TotalGroups > 0) {
	$Page->loadRowValues(TRUE);
	$Page->GroupCount = 1;
}
$Page->GroupIndexes = InitArray(2, -1);
$Page->GroupIndexes[0] = -1;
$Page->GroupIndexes[1] = $Page->StopGroup - $Page->StartGroup + 1;
while ($Page->Recordset && !$Page->Recordset->EOF && $Page->GroupCount <= $Page->DisplayGroups || $Page->ShowHeader) {

	// Show dummy header for custom template
	// Show header

	if ($Page->ShowHeader) {
?>
<?php if ($Page->Export <> "pdf") { ?>
<?php if ($Page->Export == "word" || $Page->Export == "excel") { ?>
<div class="ew-grid"<?php echo $Page->ReportTableStyle ?>>
<?php } else { ?>
<div class="card ew-card ew-grid"<?php echo $Page->ReportTableStyle ?>>
<?php } ?>
<?php } ?>
<!-- Report grid (begin) -->
<?php if ($Page->Export <> "pdf") { ?>
<div id="gmp__user_report" class="<?php if (IsResponsiveLayout()) { echo "table-responsive "; } ?>ew-grid-middle-panel">
<?php } ?>
<table class="<?php echo $Page->ReportTableClass ?>">
<thead>
	<!-- Table header -->
	<tr class="ew-table-header">
<?php if ($Page->appointment_id->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="appointment_id"><div class="_user_report_appointment_id"><span class="ew-table-header-caption"><?php echo $Page->appointment_id->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="appointment_id">
<?php if ($Page->sortUrl($Page->appointment_id) == "") { ?>
		<div class="ew-table-header-btn _user_report_appointment_id">
			<span class="ew-table-header-caption"><?php echo $Page->appointment_id->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_appointment_id" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->appointment_id) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->appointment_id->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->appointment_id->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->appointment_id->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->app_date->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="app_date"><div class="_user_report_app_date"><span class="ew-table-header-caption"><?php echo $Page->app_date->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="app_date">
<?php if ($Page->sortUrl($Page->app_date) == "") { ?>
		<div class="ew-table-header-btn _user_report_app_date">
			<span class="ew-table-header-caption"><?php echo $Page->app_date->caption() ?></span>
	<?php if (!$DashboardReport) { ?>
			<a class="ew-table-header-popup" title="<?php echo $ReportLanguage->phrase("Filter"); ?>" onclick="ew.showPopup.call(this, event, { id: 'x_app_date', form: 'f_user_reportrpt', name: '_user_report_app_date', range: false, from: '<?php echo $Page->app_date->RangeFrom; ?>', to: '<?php echo $Page->app_date->RangeTo; ?>' });" id="x_app_date<?php echo $Page->Counts[0][0]; ?>"><span class="icon-filter"></span></a>
	<?php } ?>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_app_date" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->app_date) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->app_date->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->app_date->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->app_date->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
	<?php if (!$DashboardReport) { ?>
			<a class="ew-table-header-popup" title="<?php echo $ReportLanguage->phrase("Filter"); ?>" onclick="ew.showPopup.call(this, event, { id: 'x_app_date', form: 'f_user_reportrpt', name: '_user_report_app_date', range: false, from: '<?php echo $Page->app_date->RangeFrom; ?>', to: '<?php echo $Page->app_date->RangeTo; ?>' });" id="x_app_date<?php echo $Page->Counts[0][0]; ?>"><span class="icon-filter"></span></a>
	<?php } ?>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->app_time->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="app_time"><div class="_user_report_app_time"><span class="ew-table-header-caption"><?php echo $Page->app_time->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="app_time">
<?php if ($Page->sortUrl($Page->app_time) == "") { ?>
		<div class="ew-table-header-btn _user_report_app_time">
			<span class="ew-table-header-caption"><?php echo $Page->app_time->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_app_time" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->app_time) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->app_time->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->app_time->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->app_time->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->Vehicle_rto_number->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="Vehicle_rto_number"><div class="_user_report_Vehicle_rto_number"><span class="ew-table-header-caption"><?php echo $Page->Vehicle_rto_number->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="Vehicle_rto_number">
<?php if ($Page->sortUrl($Page->Vehicle_rto_number) == "") { ?>
		<div class="ew-table-header-btn _user_report_Vehicle_rto_number">
			<span class="ew-table-header-caption"><?php echo $Page->Vehicle_rto_number->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_Vehicle_rto_number" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->Vehicle_rto_number) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->Vehicle_rto_number->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->Vehicle_rto_number->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->Vehicle_rto_number->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->staffstaff_id->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="staffstaff_id"><div class="_user_report_staffstaff_id"><span class="ew-table-header-caption"><?php echo $Page->staffstaff_id->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="staffstaff_id">
<?php if ($Page->sortUrl($Page->staffstaff_id) == "") { ?>
		<div class="ew-table-header-btn _user_report_staffstaff_id">
			<span class="ew-table-header-caption"><?php echo $Page->staffstaff_id->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_staffstaff_id" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->staffstaff_id) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->staffstaff_id->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->staffstaff_id->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->staffstaff_id->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->customercustomer_id->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="customercustomer_id"><div class="_user_report_customercustomer_id"><span class="ew-table-header-caption"><?php echo $Page->customercustomer_id->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="customercustomer_id">
<?php if ($Page->sortUrl($Page->customercustomer_id) == "") { ?>
		<div class="ew-table-header-btn _user_report_customercustomer_id">
			<span class="ew-table-header-caption"><?php echo $Page->customercustomer_id->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_customercustomer_id" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->customercustomer_id) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->customercustomer_id->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->customercustomer_id->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->customercustomer_id->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->statusstatus_id->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="statusstatus_id"><div class="_user_report_statusstatus_id"><span class="ew-table-header-caption"><?php echo $Page->statusstatus_id->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="statusstatus_id">
<?php if ($Page->sortUrl($Page->statusstatus_id) == "") { ?>
		<div class="ew-table-header-btn _user_report_statusstatus_id">
			<span class="ew-table-header-caption"><?php echo $Page->statusstatus_id->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_statusstatus_id" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->statusstatus_id) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->statusstatus_id->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->statusstatus_id->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->statusstatus_id->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->customer_id->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="customer_id"><div class="_user_report_customer_id"><span class="ew-table-header-caption"><?php echo $Page->customer_id->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="customer_id">
<?php if ($Page->sortUrl($Page->customer_id) == "") { ?>
		<div class="ew-table-header-btn _user_report_customer_id">
			<span class="ew-table-header-caption"><?php echo $Page->customer_id->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_customer_id" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->customer_id) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->customer_id->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->customer_id->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->customer_id->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->Useruser_id->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="Useruser_id"><div class="_user_report_Useruser_id"><span class="ew-table-header-caption"><?php echo $Page->Useruser_id->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="Useruser_id">
<?php if ($Page->sortUrl($Page->Useruser_id) == "") { ?>
		<div class="ew-table-header-btn _user_report_Useruser_id">
			<span class="ew-table-header-caption"><?php echo $Page->Useruser_id->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_Useruser_id" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->Useruser_id) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->Useruser_id->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->Useruser_id->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->Useruser_id->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->reg_date->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="reg_date"><div class="_user_report_reg_date"><span class="ew-table-header-caption"><?php echo $Page->reg_date->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="reg_date">
<?php if ($Page->sortUrl($Page->reg_date) == "") { ?>
		<div class="ew-table-header-btn _user_report_reg_date">
			<span class="ew-table-header-caption"><?php echo $Page->reg_date->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_reg_date" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->reg_date) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->reg_date->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->reg_date->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->reg_date->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->user_id->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="user_id"><div class="_user_report_user_id"><span class="ew-table-header-caption"><?php echo $Page->user_id->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="user_id">
<?php if ($Page->sortUrl($Page->user_id) == "") { ?>
		<div class="ew-table-header-btn _user_report_user_id">
			<span class="ew-table-header-caption"><?php echo $Page->user_id->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_user_id" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->user_id) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->user_id->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->user_id->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->user_id->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->user_name->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="user_name"><div class="_user_report_user_name"><span class="ew-table-header-caption"><?php echo $Page->user_name->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="user_name">
<?php if ($Page->sortUrl($Page->user_name) == "") { ?>
		<div class="ew-table-header-btn _user_report_user_name">
			<span class="ew-table-header-caption"><?php echo $Page->user_name->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_user_name" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->user_name) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->user_name->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->user_name->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->user_name->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->user_pass->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="user_pass"><div class="_user_report_user_pass"><span class="ew-table-header-caption"><?php echo $Page->user_pass->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="user_pass">
<?php if ($Page->sortUrl($Page->user_pass) == "") { ?>
		<div class="ew-table-header-btn _user_report_user_pass">
			<span class="ew-table-header-caption"><?php echo $Page->user_pass->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_user_pass" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->user_pass) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->user_pass->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->user_pass->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->user_pass->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->user_email->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="user_email"><div class="_user_report_user_email"><span class="ew-table-header-caption"><?php echo $Page->user_email->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="user_email">
<?php if ($Page->sortUrl($Page->user_email) == "") { ?>
		<div class="ew-table-header-btn _user_report_user_email">
			<span class="ew-table-header-caption"><?php echo $Page->user_email->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_user_email" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->user_email) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->user_email->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->user_email->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->user_email->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->user_add->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="user_add"><div class="_user_report_user_add"><span class="ew-table-header-caption"><?php echo $Page->user_add->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="user_add">
<?php if ($Page->sortUrl($Page->user_add) == "") { ?>
		<div class="ew-table-header-btn _user_report_user_add">
			<span class="ew-table-header-caption"><?php echo $Page->user_add->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_user_add" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->user_add) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->user_add->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->user_add->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->user_add->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->user_phone->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="user_phone"><div class="_user_report_user_phone"><span class="ew-table-header-caption"><?php echo $Page->user_phone->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="user_phone">
<?php if ($Page->sortUrl($Page->user_phone) == "") { ?>
		<div class="ew-table-header-btn _user_report_user_phone">
			<span class="ew-table-header-caption"><?php echo $Page->user_phone->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_user_phone" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->user_phone) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->user_phone->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->user_phone->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->user_phone->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->user_sec_ques->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="user_sec_ques"><div class="_user_report_user_sec_ques"><span class="ew-table-header-caption"><?php echo $Page->user_sec_ques->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="user_sec_ques">
<?php if ($Page->sortUrl($Page->user_sec_ques) == "") { ?>
		<div class="ew-table-header-btn _user_report_user_sec_ques">
			<span class="ew-table-header-caption"><?php echo $Page->user_sec_ques->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_user_sec_ques" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->user_sec_ques) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->user_sec_ques->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->user_sec_ques->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->user_sec_ques->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->user_sec_ans->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="user_sec_ans"><div class="_user_report_user_sec_ans"><span class="ew-table-header-caption"><?php echo $Page->user_sec_ans->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="user_sec_ans">
<?php if ($Page->sortUrl($Page->user_sec_ans) == "") { ?>
		<div class="ew-table-header-btn _user_report_user_sec_ans">
			<span class="ew-table-header-caption"><?php echo $Page->user_sec_ans->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_user_sec_ans" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->user_sec_ans) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->user_sec_ans->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->user_sec_ans->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->user_sec_ans->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->companycompany_id->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="companycompany_id"><div class="_user_report_companycompany_id"><span class="ew-table-header-caption"><?php echo $Page->companycompany_id->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="companycompany_id">
<?php if ($Page->sortUrl($Page->companycompany_id) == "") { ?>
		<div class="ew-table-header-btn _user_report_companycompany_id">
			<span class="ew-table-header-caption"><?php echo $Page->companycompany_id->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_companycompany_id" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->companycompany_id) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->companycompany_id->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->companycompany_id->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->companycompany_id->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
<?php if ($Page->otp->Visible) { ?>
<?php if ($Page->Export <> "" || $Page->DrillDown) { ?>
	<td data-field="otp"><div class="_user_report_otp"><span class="ew-table-header-caption"><?php echo $Page->otp->caption() ?></span></div></td>
<?php } else { ?>
	<td data-field="otp">
<?php if ($Page->sortUrl($Page->otp) == "") { ?>
		<div class="ew-table-header-btn _user_report_otp">
			<span class="ew-table-header-caption"><?php echo $Page->otp->caption() ?></span>
		</div>
<?php } else { ?>
		<div class="ew-table-header-btn ew-pointer _user_report_otp" onclick="ew.sort(event,'<?php echo $Page->sortUrl($Page->otp) ?>',0);">
			<span class="ew-table-header-caption"><?php echo $Page->otp->caption() ?></span>
			<span class="ew-table-header-sort"><?php if ($Page->otp->getSort() == "ASC") { ?><i class="fa fa-sort-up"></i><?php } elseif ($Page->otp->getSort() == "DESC") { ?><i class="fa fa-sort-down"></i><?php } ?></span>
		</div>
<?php } ?>
	</td>
<?php } ?>
<?php } ?>
	</tr>
</thead>
<tbody>
<?php
		if ($Page->TotalGroups == 0) break; // Show header only
		$Page->ShowHeader = FALSE;
	}
	$Page->RecordCount++;
	$Page->RecordIndex++;
?>
<?php

		// Render detail row
		$Page->resetAttributes();
		$Page->RowType = ROWTYPE_DETAIL;
		$Page->renderRow();
?>
	<tr<?php echo $Page->rowAttributes(); ?>>
<?php if ($Page->appointment_id->Visible) { ?>
		<td data-field="appointment_id"<?php echo $Page->appointment_id->cellAttributes() ?>>
<span<?php echo $Page->appointment_id->viewAttributes() ?>><?php echo $Page->appointment_id->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->app_date->Visible) { ?>
		<td data-field="app_date"<?php echo $Page->app_date->cellAttributes() ?>>
<span<?php echo $Page->app_date->viewAttributes() ?>><?php echo $Page->app_date->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->app_time->Visible) { ?>
		<td data-field="app_time"<?php echo $Page->app_time->cellAttributes() ?>>
<span<?php echo $Page->app_time->viewAttributes() ?>><?php echo $Page->app_time->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->Vehicle_rto_number->Visible) { ?>
		<td data-field="Vehicle_rto_number"<?php echo $Page->Vehicle_rto_number->cellAttributes() ?>>
<span<?php echo $Page->Vehicle_rto_number->viewAttributes() ?>><?php echo $Page->Vehicle_rto_number->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->staffstaff_id->Visible) { ?>
		<td data-field="staffstaff_id"<?php echo $Page->staffstaff_id->cellAttributes() ?>>
<span<?php echo $Page->staffstaff_id->viewAttributes() ?>><?php echo $Page->staffstaff_id->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->customercustomer_id->Visible) { ?>
		<td data-field="customercustomer_id"<?php echo $Page->customercustomer_id->cellAttributes() ?>>
<span<?php echo $Page->customercustomer_id->viewAttributes() ?>><?php echo $Page->customercustomer_id->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->statusstatus_id->Visible) { ?>
		<td data-field="statusstatus_id"<?php echo $Page->statusstatus_id->cellAttributes() ?>>
<span<?php echo $Page->statusstatus_id->viewAttributes() ?>><?php echo $Page->statusstatus_id->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->customer_id->Visible) { ?>
		<td data-field="customer_id"<?php echo $Page->customer_id->cellAttributes() ?>>
<span<?php echo $Page->customer_id->viewAttributes() ?>><?php echo $Page->customer_id->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->Useruser_id->Visible) { ?>
		<td data-field="Useruser_id"<?php echo $Page->Useruser_id->cellAttributes() ?>>
<span<?php echo $Page->Useruser_id->viewAttributes() ?>><?php echo $Page->Useruser_id->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->reg_date->Visible) { ?>
		<td data-field="reg_date"<?php echo $Page->reg_date->cellAttributes() ?>>
<span<?php echo $Page->reg_date->viewAttributes() ?>><?php echo $Page->reg_date->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->user_id->Visible) { ?>
		<td data-field="user_id"<?php echo $Page->user_id->cellAttributes() ?>>
<span<?php echo $Page->user_id->viewAttributes() ?>><?php echo $Page->user_id->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->user_name->Visible) { ?>
		<td data-field="user_name"<?php echo $Page->user_name->cellAttributes() ?>>
<span<?php echo $Page->user_name->viewAttributes() ?>><?php echo $Page->user_name->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->user_pass->Visible) { ?>
		<td data-field="user_pass"<?php echo $Page->user_pass->cellAttributes() ?>>
<span<?php echo $Page->user_pass->viewAttributes() ?>><?php echo $Page->user_pass->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->user_email->Visible) { ?>
		<td data-field="user_email"<?php echo $Page->user_email->cellAttributes() ?>>
<span<?php echo $Page->user_email->viewAttributes() ?>><?php echo $Page->user_email->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->user_add->Visible) { ?>
		<td data-field="user_add"<?php echo $Page->user_add->cellAttributes() ?>>
<span<?php echo $Page->user_add->viewAttributes() ?>><?php echo $Page->user_add->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->user_phone->Visible) { ?>
		<td data-field="user_phone"<?php echo $Page->user_phone->cellAttributes() ?>>
<span<?php echo $Page->user_phone->viewAttributes() ?>><?php echo $Page->user_phone->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->user_sec_ques->Visible) { ?>
		<td data-field="user_sec_ques"<?php echo $Page->user_sec_ques->cellAttributes() ?>>
<span<?php echo $Page->user_sec_ques->viewAttributes() ?>><?php echo $Page->user_sec_ques->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->user_sec_ans->Visible) { ?>
		<td data-field="user_sec_ans"<?php echo $Page->user_sec_ans->cellAttributes() ?>>
<span<?php echo $Page->user_sec_ans->viewAttributes() ?>><?php echo $Page->user_sec_ans->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->companycompany_id->Visible) { ?>
		<td data-field="companycompany_id"<?php echo $Page->companycompany_id->cellAttributes() ?>>
<span<?php echo $Page->companycompany_id->viewAttributes() ?>><?php echo $Page->companycompany_id->getViewValue() ?></span></td>
<?php } ?>
<?php if ($Page->otp->Visible) { ?>
		<td data-field="otp"<?php echo $Page->otp->cellAttributes() ?>>
<span<?php echo $Page->otp->viewAttributes() ?>><?php echo $Page->otp->getViewValue() ?></span></td>
<?php } ?>
	</tr>
<?php

		// Accumulate page summary
		$Page->accumulateSummary();

		// Get next record
		$Page->loadRowValues();
	$Page->GroupCount++;
} // End while
?>
<?php if ($Page->TotalGroups > 0) { ?>
</tbody>
<tfoot>
	</tfoot>
<?php } elseif (!$Page->ShowHeader && TRUE) { // No header displayed ?>
<?php if ($Page->Export <> "pdf") { ?>
<?php if ($Page->Export == "word" || $Page->Export == "excel") { ?>
<div class="ew-grid"<?php echo $Page->ReportTableStyle ?>>
<?php } else { ?>
<div class="card ew-card ew-grid"<?php echo $Page->ReportTableStyle ?>>
<?php } ?>
<?php } ?>
<!-- Report grid (begin) -->
<?php if ($Page->Export <> "pdf") { ?>
<div id="gmp__user_report" class="<?php if (IsResponsiveLayout()) { echo "table-responsive "; } ?>ew-grid-middle-panel">
<?php } ?>
<table class="<?php echo $Page->ReportTableClass ?>">
<?php } ?>
<?php if ($Page->TotalGroups > 0 || TRUE) { // Show footer ?>
</table>
<?php if ($Page->Export <> "pdf") { ?>
</div>
<?php } ?>
<?php if ($Page->Export == "" && !($Page->DrillDown && $Page->TotalGroups > 0)) { ?>
<div class="card-footer ew-grid-lower-panel">
<?php include "_user_report_pager.php" ?>
<div class="clearfix"></div>
</div>
<?php } ?>
<?php if ($Page->Export <> "pdf") { ?>
</div>
<?php } ?>
<?php } ?>
<?php if ($Page->Export <> "pdf") { ?>
</div>
<?php } ?>
<!-- Summary Report Ends -->
<?php if ($Page->Export == "" && !$DashboardReport) { ?>
</div>
<!-- /#ew-center -->
<?php } ?>
<?php if ($Page->Export == "" && !$DashboardReport) { ?>
</div>
<!-- /.row -->
<?php } ?>
<?php if ($Page->Export == "" && !$DashboardReport) { ?>
</div>
<!-- /.ew-container -->
<?php } ?>
<?php
$Page->showPageFooter();
if (DEBUG_ENABLED)
	echo GetDebugMessage();
?>
<?php

// Close recordsets
if ($Page->GroupRecordset)
	$Page->GroupRecordset->Close();
if ($Page->Recordset)
	$Page->Recordset->Close();
?>
<?php if ($Page->Export == "" && !$Page->DrillDown && !$DashboardReport) { ?>
<script>

// Write your table-specific startup script here
// console.log("page loaded");

</script>
<?php } ?>
<?php if (!$DashboardReport) { ?>
<?php include_once "rfooter.php" ?>
<?php } ?>
<?php
$Page->terminate();
if (isset($OldPage))
	$Page = $OldPage;
?>